// =====================================================================
//  Lab 4 - Observadores de estado - Motor DC Pololu 37D 50:1 con ESP32 + TB6612FNG
//  CORRECCIÓN: motor 2 (antes decia motor 3)
//
//  Que hace:
//   1. Genera PWM sobre PWMA; AIN1/AIN2 seleccionan el sentido de giro.
//   2. Cuenta el encoder en cuadratura x4 con el periferico PCNT (hardware).
//   3. Cada Ts calcula omega [rad/s] en el eje del MOTOR.
//      CORRECCIÓN: eje del motor (convencion SI del mlx); el base medía el eje de salida
//   4. ADICIÓN: corre el observador de Luenberger y el filtro de Kalman cada Ts.
//   5. ADICIÓN: Core 1 -> tarea de control (encoder, estimadores, PWM).
//               Core 0 -> Wi-Fi AP, pagina HTTP y WebSocket (entradas y graficas).
//
//  Comandos (ASCII por serial: G, S, X, D<val>, I)  -> no se usa en este archivo
//  OPTIMIZACIÓN: los comandos llegan por WebSocket como JSON:
//    {"type":"set", fac, q11, q22, r, pwm}   {"type":"run","on":bool}
//    {"type":"reset"}                        {"type":"defaults"}
//    {"type":"ramp","on":bool}   (ADICIÓN: rampa / escalon)
//
//  Formato de datos (por WebSocket, unidades del modelo):
//    [t, y, xl0, xl1, xk0, xk1, pm11, pm22, pp11, pp22, k1, k2, u%]
// =====================================================================
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>
#include <ArduinoJson.h>
#include <cmath>
#include "driver/pcnt.h"
#include "esp_timer.h"

#include "config.h"
#include "estimators.h"
#include "web_page.h"

// enum Mode : uint8_t { MODE_IDLE, MODE_PROFILE, MODE_MANUAL, MODE_STREAM };   -> no se usa en este archivo
// static Mode g_mode = MODE_IDLE;                                               -> no se usa en este archivo

// ---------------------------------------------------------------------
//  ADICIÓN: modelo del motor 2 (c2d zoh, Ts = 8 ms)
// ---------------------------------------------------------------------
static const Model2 MODEL = { { {AD11, AD12}, {AD21, AD22} }, {BD1, BD2} };

// ---------------------------------------------------------------------
//  ADICIÓN: datos compartidos entre cores
// ---------------------------------------------------------------------
struct Params {
    double fac;          // Luenberger: polos 'fac' veces mas rapidos
    double L[2];         // ganancia del Luenberger calculada para 'fac'
    double q11, q22;     // Q del Kalman (diagonal) [A^2, (rad/s)^2]
    double r;            // R del Kalman [(rad/s)^2]
    double pwm;          // comando pedido [%], -MAX_DUTY_MANUAL..MAX_DUTY_MANUAL
    bool   run;          // motor habilitado
    bool   ramp_on;      // ADICIÓN: true = rampa RAMP_PCT_PER_S, false = escalon directo
};

struct Sample {          // un periodo de control, unidades del modelo
    float t;             // [s]
    float y;             // omega medida [rad/s motor]
    float xl0, xl1;      // estimacion Luenberger [A, rad/s]
    float xk0, xk1;      // estimacion Kalman     [A, rad/s]
    float pm11, pm22;    // diagonal de la covarianza a priori
    float pp11, pp22;    // diagonal de la covarianza a posteriori
    float k1, k2;        // ganancia de Kalman
    float u;             // duty REALMENTE aplicado (despues de la rampa) [%]
};

static portMUX_TYPE  g_mux = portMUX_INITIALIZER_UNLOCKED;
static Params        g_params;
static volatile bool g_reset_req = false;
static QueueHandle_t g_queue;

// ---------------------------------------------------------------------
//  Temporizacion (del base): esp_timer periodico + notificacion a la tarea
// ---------------------------------------------------------------------
static esp_timer_handle_t g_timer = nullptr;
static TaskHandle_t       g_task  = nullptr;     // tarea de control (core 1)
// static volatile uint32_t g_tick_count = 0;    -> no se usa en este archivo (t sale de esp_timer)
static volatile uint32_t  g_missed = 0;          // ciclos perdidos (sobrecarga)

static volatile uint32_t g_dt_max_us   = 0;      // peor periodo desde el ultimo reporte
static volatile uint32_t g_exec_max_us = 0;      // peor tiempo de calculo desde el ultimo reporte
static volatile uint32_t g_dropped     = 0;      // muestras perdidas porque la cola estaba llena

// static bool    g_first = true;                       -> no se usa en este archivo
// static int64_t g_t0 = 0, g_t_prev = 0;               -> no se usa en este archivo (locales de control_task)
// static float   g_manual_duty = 0.0f;                 -> no se usa en este archivo (g_params.pwm)
// static float   g_duty_cur    = 0.0f;                 -> no se usa en este archivo (local de control_task)
// static uint32_t g_last_cmd_ms = 0;                   -> no se usa en este archivo
// static float   g_prev_duty = 0.0f;                   -> no se usa en este archivo

// Copia del ultimo diseno del lado web (solo la toca la tarea web)
static LuenbergerDesign g_design;
static String           g_last_err;

// ---------------------------------------------------------------------
//  PWM / motor: PWM por PWMA; AIN1 y AIN2 son digitales para direccion
// ---------------------------------------------------------------------
constexpr uint32_t PWM_MAX = (1u << PWM_BITS) - 1;

static void pwm_init() {
    pinMode(PIN_AIN1, OUTPUT);
    pinMode(PIN_AIN2, OUTPUT);

    digitalWrite(PIN_AIN1, LOW);
    digitalWrite(PIN_AIN2, LOW);

#if ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcAttach(PIN_PWMA, PWM_FREQ_HZ, PWM_BITS);
    ledcWrite(PIN_PWMA, 0);
#else
    // CORRECCIÓN: canal PWM_CHANNEL de config.h (antes 0 fijo)
    ledcSetup(PWM_CHANNEL, PWM_FREQ_HZ, PWM_BITS);
    ledcAttachPin(PIN_PWMA, PWM_CHANNEL);
    ledcWrite(PWM_CHANNEL, 0);
#endif
}

// Escribe el duty PWM en PWMA (0..PWM_MAX).
static void pwm_write(uint32_t duty) {
    duty = min(duty, PWM_MAX);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcWrite(PIN_PWMA, duty);
#else
    ledcWrite(PWM_CHANNEL, duty);
#endif
}

// ADICIÓN: sentido actual (2 = sin inicializar, obliga a fijar los pines en la 1a llamada)
static int g_dir = 2;

// duty en % (-100..100).
// PWMA recibe PWM; AIN1/AIN2 solo seleccionan el sentido.
// STBY debe estar en HIGH por hardware para habilitar el TB6612FNG.
static void motor_set(double duty) {
    duty = fmin(100.0, fmax(-100.0, duty));

    const uint32_t pwm_value = (uint32_t)lround(fabs(duty) / 100.0 * PWM_MAX);
    const int dir = (duty > 0.0) - (duty < 0.0);

    // CORRECCIÓN: el base ponia PWMA = 0 en CADA llamada (cada Ts) antes de fijar la
    //             direccion, lo que corta el PWM un instante en cada muestra. Ahora se
    //             desactiva PWMA solo cuando cambia el sentido de giro.
    if (dir != g_dir) {
        pwm_write(0);
        if (dir > 0) {
            digitalWrite(PIN_AIN1, HIGH);
            digitalWrite(PIN_AIN2, LOW);
        } else if (dir < 0) {
            digitalWrite(PIN_AIN1, LOW);
            digitalWrite(PIN_AIN2, HIGH);
        } else {
            // CORRECCIÓN: freno en corto (AIN1 = AIN2 = HIGH) = bornes en corto = V = 0,
            //             que es lo que supone el modelo. El base dejaba el motor libre
            //             (LOW/LOW), que equivale a i = 0, no a V = 0.
            digitalWrite(PIN_AIN1, HIGH);
            digitalWrite(PIN_AIN2, HIGH);
        }
        g_dir = dir;
    }

    pwm_write(pwm_value);
}

// ---------------------------------------------------------------------
//  Encoder en cuadratura x4 con PCNT
// ---------------------------------------------------------------------
static const pcnt_unit_t PCNT_U = PCNT_UNIT_0;
// CORRECCIÓN: el contador vuelve a 0 en +-PCNT_LIM por hardware (eventos de limite);
//             el base lo borraba por software al pasar de 20000, y las cuentas que
//             llegaban entre la lectura y el borrado se perdian
static constexpr int16_t PCNT_LIM = 10000;
static int16_t g_last_cnt = 0;

static void encoder_init() {
    pcnt_config_t c = {};
    c.unit = PCNT_U;
    c.counter_h_lim = PCNT_LIM;
    c.counter_l_lim = -PCNT_LIM;

    // CORRECCIÓN: modos del banco (pines A/B invertidos respecto al base, ver config.h)
    // Canal 0: pulso = A, control = B
    c.channel = PCNT_CHANNEL_0;
    c.pulse_gpio_num = PIN_ENC_A;  c.ctrl_gpio_num = PIN_ENC_B;
    c.pos_mode = PCNT_COUNT_DEC;   c.neg_mode = PCNT_COUNT_INC;
    c.lctrl_mode = PCNT_MODE_REVERSE; c.hctrl_mode = PCNT_MODE_KEEP;
    pcnt_unit_config(&c);

    // Canal 1: pulso = B, control = A  (completa los 4 flancos)
    c.channel = PCNT_CHANNEL_1;
    c.pulse_gpio_num = PIN_ENC_B;  c.ctrl_gpio_num = PIN_ENC_A;
    c.pos_mode = PCNT_COUNT_INC;   c.neg_mode = PCNT_COUNT_DEC;
    c.lctrl_mode = PCNT_MODE_REVERSE; c.hctrl_mode = PCNT_MODE_KEEP;
    pcnt_unit_config(&c);

    // ADICIÓN: pcnt_unit_config() desactiva los eventos de limite; se activan para que
    //          el contador vuelva a 0 en +-PCNT_LIM (como el ejemplo rotary_encoder de ESP-IDF)
    pcnt_event_enable(PCNT_U, PCNT_EVT_H_LIM);
    pcnt_event_enable(PCNT_U, PCNT_EVT_L_LIM);

    // CORRECCIÓN: filtro ENC_FILTER de config.h (antes 1000 fijo)
    pcnt_set_filter_value(PCNT_U, ENC_FILTER);
    pcnt_filter_enable(PCNT_U);

    pcnt_counter_pause(PCNT_U);
    pcnt_counter_clear(PCNT_U);
    pcnt_counter_resume(PCNT_U);
}

static void encoder_reset() {
    pcnt_counter_clear(PCNT_U);
    g_last_cnt = 0;
}

// Devuelve las cuentas nuevas desde la ultima llamada.
static int32_t encoder_update() {
    int16_t v = 0;
    pcnt_get_counter_value(PCNT_U, &v);
    int32_t d = (int32_t)v - (int32_t)g_last_cnt;
    g_last_cnt = v;
    // CORRECCIÓN: desenrollar el salto cuando el contador volvio a 0 en +-PCNT_LIM
    if (d < -PCNT_LIM / 2)      d += PCNT_LIM;   // el contador paso por +LIM
    else if (d > PCNT_LIM / 2)  d -= PCNT_LIM;   // el contador paso por -LIM
    // if (v > 20000 || v < -20000) { pcnt_counter_clear(PCNT_U); g_last_cnt = 0; }   -> no se usa en este archivo
    return d;
}

// ---------------------------------------------------------------------
//  Salida serial
// ---------------------------------------------------------------------
// static float profile_total_s() { ... }                         -> no se usa en este archivo
// static void  print_info() { "#COLS,..." / "#INFO,..." }         -> no se usa en este archivo
// static void  print_row(uint32_t k, int64_t t_us, float omega)   -> no se usa en este archivo
//              (los datos van por WebSocket, ver push_samples)

// ---------------------------------------------------------------------
//  Control de la ejecucion
// ---------------------------------------------------------------------
static void tick_cb(void*) {
    // g_tick_count = g_tick_count + 1;   -> no se usa en este archivo
    xTaskNotifyGive(g_task);
}

// static void start_run(Mode m) { ... }          -> no se usa en este archivo
// static void stop_run(const char* tag) { ... }  -> no se usa en este archivo
//             (el motor se habilita/deshabilita con g_params.run desde la pagina)

// ---------------------------------------------------------------------
//  Core 1 - tarea de control: se ejecuta una vez por periodo Ts
//  OPTIMIZACIÓN: do_tick() del base pasa a ser el cuerpo del lazo de control_task
//  CORRECCIÓN (respecto a la version del banco): el periodo lo marca esp_timer
//             (resolucion de us, como el base) y no vTaskDelayUntil con ticks de 1 ms;
//             los ciclos perdidos se cuentan en g_missed
// ---------------------------------------------------------------------
static void control_task(void*) {
    Luenberger lu;  lu.reset();
    Kalman     kf;  kf.reset(DEF_P011, DEF_P022);

    Params p;
    portENTER_CRITICAL(&g_mux); p = g_params; portEXIT_CRITICAL(&g_mux);

    encoder_reset();
    int64_t       t_prev = esp_timer_get_time();
    const int64_t t0     = t_prev;
    double y_prev = 0.0, u_prev = 0.0;          // y(k-1) [rad/s], u(k-1) [V]
    double duty_cur = 0.0;                      // duty aplicado (despues de la rampa) [%]
    const double max_step = RAMP_PCT_PER_S * TS_S;   // [%] por muestra

    for (;;) {
        const uint32_t n = ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        if (n > 1) g_missed = g_missed + (n - 1);     // ciclos que no alcanzamos a procesar

        // 1) Velocidad: lo PRIMERO es leer el encoder (instante de muestreo exacto)
        const int64_t  now   = esp_timer_get_time();
        const int32_t  d     = encoder_update();
        const uint32_t dt_us = (uint32_t)(now - t_prev);   // dt real medido
        t_prev = now;
        if (dt_us > g_dt_max_us) g_dt_max_us = dt_us;
        const double y = ENC_SIGN * (double)d * (2.0 * M_PI / ENC_CPR_MOTOR) / (dt_us * 1e-6);

        // 2) ADICIÓN: los parametros nuevos solo se aplican aqui, al inicio de una muestra
        bool do_reset;
        portENTER_CRITICAL(&g_mux);
        p = g_params;
        do_reset = g_reset_req;
        g_reset_req = false;
        portEXIT_CRITICAL(&g_mux);
        lu.L[0] = p.L[0];  lu.L[1] = p.L[1];
        if (do_reset) { lu.reset(); kf.reset(DEF_P011, DEF_P022); }

        // 3) ADICIÓN: estimadores
        lu.step(MODEL, y_prev, u_prev);                  // predictor: usa y(k-1), u(k-1)
        kf.step(MODEL, p.q11, p.q22, p.r, u_prev, y);    // predice con u(k-1), corrige con y(k)

        // 4) Decidir el duty del proximo intervalo
        // if (g_mode == MODE_PROFILE) { ... }                      -> no se usa en este archivo
        // if (millis() - g_last_cmd_ms > lim) stop_run("#TIMEOUT"); -> no se usa en este archivo
        double target = p.run ? p.pwm : 0.0;
        target = fmin(MAX_DUTY_MANUAL, fmax(-MAX_DUTY_MANUAL, target));
        // Rampa: el duty aplicado se acerca al pedido a lo sumo RAMP_PCT_PER_S
        // ADICIÓN: tambien al parar (Stop o pagina desconectada) se baja en rampa
        // ADICIÓN: con la rampa apagada desde la pagina, el duty pedido se aplica de una vez (escalon)
        if (p.ramp_on) duty_cur += fmin(max_step, fmax(-max_step, target - duty_cur));
        else           duty_cur  = target;

        // 5) Aplicar el duty inmediatamente (inicio del intervalo, ZOH hasta la proxima muestra)
        motor_set(duty_cur);
        const double u = duty_cur * V_SUPPLY / 100.0;     // u(k) [V] con el duty realmente aplicado

        // 6) ADICIÓN: publicar la muestra para la pagina
        Sample s;
        s.t   = (float)((now - t0) * 1e-6);
        s.y   = (float)y;
        s.xl0 = (float)lu.x[0];  s.xl1 = (float)lu.x[1];
        s.xk0 = (float)kf.x[0];  s.xk1 = (float)kf.x[1];
        s.pm11 = (float)kf.Pm[0][0];  s.pm22 = (float)kf.Pm[1][1];
        s.pp11 = (float)kf.P[0][0];   s.pp22 = (float)kf.P[1][1];
        s.k1 = (float)kf.K[0];  s.k2 = (float)kf.K[1];
        s.u  = (float)duty_cur;
        if (xQueueSend(g_queue, &s, 0) != pdTRUE) g_dropped = g_dropped + 1;

        // 7) Guardar y(k) y u(k) para la siguiente muestra
        y_prev = y;
        u_prev = u;

        const uint32_t exec_us = (uint32_t)(esp_timer_get_time() - now);
        if (exec_us > g_exec_max_us) g_exec_max_us = exec_us;
    }
}

// ---------------------------------------------------------------------
//  Comandos por serial
// ---------------------------------------------------------------------
// static void exec_cmd(const char* c) { switch (c[0]) { 'G','S','X','D','I' } }   -> no se usa en este archivo
// static void handle_serial() { ... }                                            -> no se usa en este archivo

// ---------------------------------------------------------------------
//  ADICIÓN: Core 0 - tarea web (Wi-Fi AP, pagina y WebSocket)
// ---------------------------------------------------------------------
static WebServer        g_http(80);
static WebSocketsServer g_ws(81);

static void send_config(int client /* -1 = broadcast */) {
    Params p;
    portENTER_CRITICAL(&g_mux); p = g_params; portEXIT_CRITICAL(&g_mux);

    JsonDocument d;
    d["type"] = "cfg";
    d["fac"] = p.fac;  d["q11"] = p.q11;  d["q22"] = p.q22;  d["r"] = p.r;
    d["pwm"] = p.pwm;  d["run"] = p.run;
    d["L1"] = p.L[0];  d["L2"] = p.L[1];
    JsonArray pz = d["plantPoles"].to<JsonArray>();
    JsonArray oz = d["obsPoles"].to<JsonArray>();
    for (int i = 0; i < 2; ++i) {
        JsonArray a = pz.add<JsonArray>(); a.add(g_design.plant_re[i]); a.add(g_design.plant_im[i]);
        JsonArray b = oz.add<JsonArray>(); b.add(g_design.obs_re[i]);   b.add(g_design.obs_im[i]);
    }
    d["p011"] = DEF_P011;  d["p022"] = DEF_P022;
    d["ts"] = TS_S;  d["kout"] = KOUT;  d["vs"] = V_SUPPLY;
    d["facMin"] = FAC_MIN;  d["facMax"] = FAC_MAX;
    // ADICIÓN: limite de PWM y rampa para el bloqueo de la pagina
    d["pwmMax"] = MAX_DUTY_MANUAL;  d["ramp"] = RAMP_PCT_PER_S;
    d["rampOn"] = p.ramp_on;        // ADICIÓN: modo actual (rampa / escalon)
    JsonObject def = d["defaults"].to<JsonObject>();
    def["fac"] = DEF_FAC; def["q11"] = DEF_Q11; def["q22"] = DEF_Q22; def["r"] = DEF_R;
    d["err"] = g_last_err;

    String out;
    serializeJson(d, out);
    if (client < 0) g_ws.broadcastTXT(out);
    else            g_ws.sendTXT((uint8_t)client, out);
}

static void handle_set(JsonDocument& in) {
    Params p;
    portENTER_CRITICAL(&g_mux); p = g_params; portEXIT_CRITICAL(&g_mux);

    const double fac = in["fac"] | p.fac;
    const double q11 = in["q11"] | p.q11;
    const double q22 = in["q22"] | p.q22;
    const double r   = in["r"]   | p.r;
    const double pwm = in["pwm"] | p.pwm;

    g_last_err = "";
    if (!(fac >= FAC_MIN && fac <= FAC_MAX)) { g_last_err = "fac out of range";      return; }
    if (!(q11 >= 0.0 && q22 >= 0.0))         { g_last_err = "Q entries must be >= 0"; return; }
    if (!(r > 0.0))                          { g_last_err = "R must be > 0";          return; }
    // CORRECCIÓN: el PWM se limita a +-MAX_DUTY_MANUAL (antes se aceptaba -100..100);
    //             si llega un valor peligroso no se cambia nada
    if (!(fabs(pwm) <= MAX_DUTY_MANUAL)) {
        char msg[48];
        snprintf(msg, sizeof(msg), "PWM limited to \xC2\xB1%.0f %%", MAX_DUTY_MANUAL);
        g_last_err = msg;
        return;
    }

    if (fac != p.fac) {
        LuenbergerDesign dsg = design_luenberger(MODEL, fac);   // la matematica pesada queda en el core 0
        if (!dsg.ok) { g_last_err = dsg.err; return; }
        g_design = dsg;
        p.fac = fac;  p.L[0] = dsg.L[0];  p.L[1] = dsg.L[1];
    }
    p.q11 = q11;  p.q22 = q22;  p.r = r;  p.pwm = pwm;

    portENTER_CRITICAL(&g_mux); g_params = p; portEXIT_CRITICAL(&g_mux);
}

static void set_run(bool on) {
    portENTER_CRITICAL(&g_mux); g_params.run = on; portEXIT_CRITICAL(&g_mux);
}

// ADICIÓN: selector rampa / escalon de la pagina
static void set_ramp(bool on) {
    portENTER_CRITICAL(&g_mux); g_params.ramp_on = on; portEXIT_CRITICAL(&g_mux);
}

static void on_ws(uint8_t num, WStype_t type, uint8_t* payload, size_t len) {
    switch (type) {
    case WStype_CONNECTED:
        send_config(num);
        break;
    case WStype_DISCONNECTED:
        if (g_ws.connectedClients() == 0) set_run(false);   // seguridad: nadie mirando -> parar
        break;
    case WStype_TEXT: {
        JsonDocument in;
        if (deserializeJson(in, payload, len)) return;
        const char* t = in["type"] | "";
        if      (!strcmp(t, "set"))   { handle_set(in); }
        else if (!strcmp(t, "run"))   { set_run(in["on"] | false); }
        else if (!strcmp(t, "ramp"))  { set_ramp(in["on"] | true); }      // ADICIÓN
        else if (!strcmp(t, "reset")) { portENTER_CRITICAL(&g_mux); g_reset_req = true; portEXIT_CRITICAL(&g_mux); }
        else if (!strcmp(t, "defaults")) {
            JsonDocument dd;
            dd["fac"] = DEF_FAC; dd["q11"] = DEF_Q11; dd["q22"] = DEF_Q22; dd["r"] = DEF_R;
            handle_set(dd);
        }
        send_config(-1);
        break;
    }
    default: break;
    }
}

static char g_buf[12288];

static void push_samples() {
    if (g_ws.connectedClients() == 0) { xQueueReset(g_queue); return; }
    int n = snprintf(g_buf, sizeof(g_buf), "{\"type\":\"d\",\"s\":[");
    Sample s;
    int count = 0;
    while (n < (int)sizeof(g_buf) - 256 && xQueueReceive(g_queue, &s, 0) == pdTRUE) {
        n += snprintf(g_buf + n, sizeof(g_buf) - n,
            "%s[%.4f,%.5g,%.5g,%.5g,%.5g,%.5g,%.5g,%.5g,%.5g,%.5g,%.5g,%.5g,%.4g]",
            count ? "," : "",
            s.t, s.y, s.xl0, s.xl1, s.xk0, s.xk1, s.pm11, s.pm22, s.pp11, s.pp22, s.k1, s.k2, s.u);
        ++count;
    }
    if (!count) return;
    n += snprintf(g_buf + n, sizeof(g_buf) - n, "]}");
    g_ws.broadcastTXT(g_buf, n);
}

static void push_stats() {
    char b[192];
    if (g_ws.connectedClients() == 0) set_run(false);   // respaldo de seguridad del evento de desconexion
    uint32_t dt_max, ex_max, drop, missed;
    portENTER_CRITICAL(&g_mux);
    dt_max = g_dt_max_us; ex_max = g_exec_max_us; drop = g_dropped; missed = g_missed;
    g_dt_max_us = 0; g_exec_max_us = 0;
    portEXIT_CRITICAL(&g_mux);
    // ADICIÓN: ciclos perdidos (g_missed del base) en las estadisticas
    int n = snprintf(b, sizeof(b),
        "{\"type\":\"st\",\"dtMaxUs\":%u,\"execMaxUs\":%u,\"dropped\":%u,\"missed\":%u,\"clients\":%u}",
        (unsigned)dt_max, (unsigned)ex_max, (unsigned)drop, (unsigned)missed, (unsigned)g_ws.connectedClients());
    g_ws.broadcastTXT(b, n);
}

static void web_task(void*) {
    g_http.on("/", HTTP_GET, []() {
        g_http.sendHeader("Content-Encoding", "gzip");
        g_http.sendHeader("Cache-Control", "no-store");
        g_http.send_P(200, "text/html", (PGM_P)WEB_PAGE_GZ, WEB_PAGE_GZ_LEN);
    });
    g_http.onNotFound([]() { g_http.send(404, "text/plain", "Not found"); });
    g_http.begin();
    g_ws.begin();
    g_ws.onEvent(on_ws);

    uint32_t t_push = millis(), t_stats = millis();
    for (;;) {
        g_http.handleClient();
        g_ws.loop();
        const uint32_t now = millis();
        if (now - t_push  >= WEB_PUSH_MS) { t_push = now;  push_samples(); }
        if (now - t_stats >= 1000)        { t_stats = now; push_stats();   }
        vTaskDelay(1);
    }
}

// ---------------------------------------------------------------------
//  Arduino
// ---------------------------------------------------------------------
void setup() {
    Serial.begin(SERIAL_BAUD);

    pwm_init();
    motor_set(0);                     // PWM desactivado al arrancar (freno en corto)
    encoder_init();

    // ADICIÓN: diseno inicial del Luenberger y parametros por defecto
    g_design = design_luenberger(MODEL, DEF_FAC);
    g_params.fac = DEF_FAC;
    g_params.L[0] = g_design.L[0];  g_params.L[1] = g_design.L[1];
    g_params.q11 = DEF_Q11;  g_params.q22 = DEF_Q22;  g_params.r = DEF_R;
    g_params.pwm = DEF_PWM;  g_params.run = false;
    g_params.ramp_on = DEF_RAMP_ON;   // ADICIÓN
    Serial.printf("Luenberger fac=%.2f ok=%d  L=[%.6g; %.6g]\n",
                  DEF_FAC, g_design.ok, g_design.L[0], g_design.L[1]);

    g_queue = xQueueCreate(SAMPLE_QUEUE_LEN, sizeof(Sample));

    // ADICIÓN: Wi-Fi como punto de acceso (WIFI_PASS vacio = red abierta)
    WiFi.mode(WIFI_AP);
    WiFi.softAP(WIFI_SSID, WIFI_PASS);
    Serial.printf("Wi-Fi AP '%s'  ->  http://%s\n", WIFI_SSID, WiFi.softAPIP().toString().c_str());

    // OPTIMIZACIÓN: dos tareas fijas a un core en lugar de loop()
    xTaskCreatePinnedToCore(control_task, "control", 4096, nullptr, CONTROL_PRIO, &g_task, CONTROL_CORE);
    xTaskCreatePinnedToCore(web_task,     "web",     8192, nullptr, WEB_PRIO,     nullptr, WEB_CORE);

    // Temporizador periodico del base: avisa a la tarea de control cada Ts
    esp_timer_create_args_t args = {};
    args.callback = &tick_cb;
    args.name = "ts_timer";
    esp_timer_create(&args, &g_timer);
    esp_timer_start_periodic(g_timer, TS_US);

    // Serial.println("#READY");  print_info();   -> no se usa en este archivo
}

void loop() {
    // handle_serial();  ...  do_tick();   -> no se usa en este archivo
    vTaskDelete(nullptr);   // todo corre en las dos tareas fijas a un core
}
