// =====================================================================
//  estimators.cpp - Diseno del Luenberger (Ackermann) y filtro de Kalman
//  ADICIÓN: archivo propio (el firmware base no tiene estimadores)
// =====================================================================
#include "estimators.h"
#include <cmath>

// ---------------------------------------------------------------------
//  Valores propios de una matriz 2x2, escritos para evitar cancelacion:
//  la raiz grande sale de la formula cuadratica, la pequena de det/grande.
// ---------------------------------------------------------------------
static void eig2(const double A[2][2], double re[2], double im[2]) {
    const double tr   = A[0][0] + A[1][1];
    const double det  = A[0][0] * A[1][1] - A[0][1] * A[1][0];
    const double h    = 0.5 * tr;
    const double disc = h * h - det;
    if (disc >= 0.0) {
        const double s   = std::sqrt(disc);
        const double big = (h >= 0.0) ? h + s : h - s;
        re[0] = big;
        re[1] = (big != 0.0) ? det / big : h - s;
        im[0] = im[1] = 0.0;
    } else {
        const double s = std::sqrt(-disc);
        re[0] = re[1] = h;
        im[0] = s;  im[1] = -s;
    }
}

// ---------------------------------------------------------------------
//  Diseno del Luenberger para un 'fac' dado
// ---------------------------------------------------------------------
LuenbergerDesign design_luenberger(const Model2& m, double fac) {
    LuenbergerDesign d{};
    d.ok  = false;
    d.err = "";

    const double (*A)[2] = m.A;
    eig2(A, d.plant_re, d.plant_im);

    // Observabilidad con C = [0 1]: O = [0 1; a21 a22], det(O) = -a21
    if (std::fabs(A[1][0]) < 1e-12) { d.err = "System not observable (a21 = 0)"; return d; }
    if (!(fac > 0.0))               { d.err = "fac must be positive"; return d; }

    // Polos deseados del observador: z_obs = z_planta^fac  (= exp(fac * s * Ts))
    if (d.plant_im[0] == 0.0) {
        if (d.plant_re[0] <= 0.0 || d.plant_re[1] <= 0.0) {
            d.err = "A plant pole is not positive real; z^fac is undefined";
            return d;
        }
        const double q1 = std::pow(d.plant_re[0], fac);
        const double q2 = std::pow(d.plant_re[1], fac);
        d.obs_re[0] = q1;  d.obs_re[1] = q2;  d.obs_im[0] = d.obs_im[1] = 0.0;
        d.alpha1 = -(q1 + q2);
        d.alpha2 = q1 * q2;
    } else {
        const double r  = std::hypot(d.plant_re[0], d.plant_im[0]);
        const double th = std::atan2(d.plant_im[0], d.plant_re[0]);
        const double rq = std::pow(r, fac), tq = fac * th;
        d.obs_re[0] = d.obs_re[1] = rq * std::cos(tq);
        d.obs_im[0] = rq * std::sin(tq);  d.obs_im[1] = -d.obs_im[0];
        d.alpha1 = -2.0 * rq * std::cos(tq);
        d.alpha2 = rq * rq;
    }

    // Ackermann: L = Phi(A) * O^-1 * [0;1],  Phi(A) = A^2 + a1 A + a2 I
    // Con C = [0 1]:  O^-1 [0;1] = [1/a21; 0]  ->  L = Phi(:,1) / a21
    double A2[2][2];
    for (int i = 0; i < 2; ++i)
        for (int j = 0; j < 2; ++j)
            A2[i][j] = A[i][0] * A[0][j] + A[i][1] * A[1][j];
    const double phi11 = A2[0][0] + d.alpha1 * A[0][0] + d.alpha2;
    const double phi21 = A2[1][0] + d.alpha1 * A[1][0];
    d.L[0] = phi11 / A[1][0];
    d.L[1] = phi21 / A[1][0];

    // Verificacion: eig(A - L C) debe ser estable
    double ALC[2][2] = { { A[0][0], A[0][1] - d.L[0] },
                         { A[1][0], A[1][1] - d.L[1] } };
    double re[2], im[2];
    eig2(ALC, re, im);
    for (int i = 0; i < 2; ++i) {
        if (std::hypot(re[i], im[i]) >= 1.0) { d.err = "Observer is unstable"; return d; }
    }
    d.ok = true;
    return d;
}

// ---------------------------------------------------------------------
//  Luenberger:  xh(k) = (A - L C) xh(k-1) + L y(k-1) + B u(k-1),  C = [0 1]
// ---------------------------------------------------------------------
void Luenberger::step(const Model2& m, double y_prev, double u_prev) {
    const double x0 = x[0], x1 = x[1];
    const double n0 = m.A[0][0] * x0 + (m.A[0][1] - L[0]) * x1 + L[0] * y_prev + m.B[0] * u_prev;
    const double n1 = m.A[1][0] * x0 + (m.A[1][1] - L[1]) * x1 + L[1] * y_prev + m.B[1] * u_prev;
    x[0] = n0;  x[1] = n1;
}

// ---------------------------------------------------------------------
//  Kalman
// ---------------------------------------------------------------------
void Kalman::reset(double p011, double p022) {
    x[0] = x[1] = 0.0;
    P[0][0] = p011; P[0][1] = 0.0; P[1][0] = 0.0; P[1][1] = p022;
    for (int i = 0; i < 2; ++i) for (int j = 0; j < 2; ++j) Pm[i][j] = P[i][j];
    K[0] = K[1] = 0.0;
}

void Kalman::step(const Model2& m, double q11, double q22, double r, double u_prev, double y) {
    const double (*A)[2] = m.A;

    // Prediccion (a priori)
    const double xm0 = A[0][0] * x[0] + A[0][1] * x[1] + m.B[0] * u_prev;
    const double xm1 = A[1][0] * x[0] + A[1][1] * x[1] + m.B[1] * u_prev;

    double AP[2][2];
    for (int i = 0; i < 2; ++i)
        for (int j = 0; j < 2; ++j)
            AP[i][j] = A[i][0] * P[0][j] + A[i][1] * P[1][j];
    for (int i = 0; i < 2; ++i)
        for (int j = 0; j < 2; ++j)
            Pm[i][j] = AP[i][0] * A[j][0] + AP[i][1] * A[j][1];
    Pm[0][0] += q11;
    Pm[1][1] += q22;

    // Correccion (a posteriori), C = [0 1]: C P- C' = P-22, P- C' = columna 2 de P-
    const double S = Pm[1][1] + r;
    K[0] = Pm[0][1] / S;
    K[1] = Pm[1][1] / S;
    const double innov = y - xm1;
    x[0] = xm0 + K[0] * innov;
    x[1] = xm1 + K[1] * innov;

    // P+ = (I - K C) P-  ->  fila i: P-(i,:) - K_i * P-(2,:)
    for (int j = 0; j < 2; ++j) {
        P[0][j] = Pm[0][j] - K[0] * Pm[1][j];
        P[1][j] = Pm[1][j] - K[1] * Pm[1][j];
    }
    // Mantener P simetrica frente al redondeo
    const double s = 0.5 * (P[0][1] + P[1][0]);
    P[0][1] = P[1][0] = s;
}
