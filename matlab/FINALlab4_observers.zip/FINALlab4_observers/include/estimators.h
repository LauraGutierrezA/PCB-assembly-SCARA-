// =====================================================================
//  estimators.h - Matematica de los estimadores (portable, sin Arduino, double)
//  Modelo: x(k) = A x(k-1) + B u(k-1),  y(k) = C x(k),  C = [0 1]
//  Estados: x = [i_a (A); omega (rad/s, eje del motor)]
//  ADICIÓN: archivo propio (el firmware base no tiene estimadores); se compila
//           tambien en el PC con test_host/test_estimators.cpp
// =====================================================================
#pragma once

struct Model2 {
    double A[2][2];
    double B[2];
};

// ---------------------------------------------------------------------
//  Luenberger (orden completo, tipo predictor, ecuacion de la guia)
//     xh(k) = (A - L C) xh(k-1) + L y(k-1) + B u(k-1)
// ---------------------------------------------------------------------
// OPTIMIZACIÓN: campos en snake_case como el base (plantRe -> plant_re, ...)
struct LuenbergerDesign {
    bool        ok;                    // false si se rechaza el diseno (se conserva la L anterior)
    const char* err;                   // motivo cuando ok == false (texto en ingles, lo ve la pagina)
    double L[2];
    double plant_re[2], plant_im[2];   // polos de la planta     (eig(A))
    double obs_re[2],   obs_im[2];     // polos del observador   (eig(A - L C))
    double alpha1, alpha2;             // polinomio deseado z^2 + a1 z + a2
};

// OPTIMIZACIÓN: nombre en snake_case como el base (antes designLuenberger)
LuenbergerDesign design_luenberger(const Model2& m, double fac);

struct Luenberger {
    double x[2];
    double L[2];
    void reset() { x[0] = 0.0; x[1] = 0.0; }
    void step(const Model2& m, double y_prev, double u_prev);
};

// ---------------------------------------------------------------------
//  Filtro de Kalman lineal (Notas 10)
//     Prediccion:  x- = A x+ + B u(k-1);   P- = A P+ A' + Q
//     Correccion:  K  = P- C' (C P- C' + R)^-1
//                  x+ = x- + K (y(k) - C x-);   P+ = (I - K C) P-
// ---------------------------------------------------------------------
struct Kalman {
    double x[2];
    double P[2][2];       // covarianza a posteriori P+
    double Pm[2][2];      // covarianza a priori P- (ultimo paso)
    double K[2];          // ultima ganancia
    void reset(double p011, double p022);
    void step(const Model2& m, double q11, double q22, double r, double u_prev, double y);
};
