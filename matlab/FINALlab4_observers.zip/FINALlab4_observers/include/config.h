// =====================================================================
//  config.h - TODO lo editable del firmware esta aqui
//  Motor: Pololu 37D 50:1 12 V, encoder 64 CPR | Driver: TB6612FNG
//  Lab 4 - Observadores y estimadores de estado (Control Digital 2026-2)
//  CORRECCIÓN: motor 2 (antes el comentario decía motor 3, pero Ad/Bd, Q y R
//              son los del motor 2 del mlx)
//  ADICIÓN: unidades del modelo:
//      estados x = [i_a (A); omega (rad/s, eje del MOTOR)],  entrada u = V
// =====================================================================
#pragma once
#include <Arduino.h>

// ---------------------------------------------------------------------
//  Comunicacion serial (debe coincidir con monitor_speed)
// ---------------------------------------------------------------------
// CORRECCIÓN: 115200; los 921600 del base eran para el stream a Simulink
constexpr uint32_t SERIAL_BAUD = 115200;

// ---------------------------------------------------------------------
//  Muestreo. Debe ser IGUAL al Ts usado en MATLAB (c2d del mlx).
// ---------------------------------------------------------------------
// CORRECCIÓN: el comentario decía 10 ms / 100 Hz; el valor es 8 ms (125 Hz)
constexpr uint32_t TS_US = 8000;                 // [us]  8 ms
// ADICIÓN: Ts en segundos (se envía a la página)
constexpr double   TS_S  = TS_US * 1e-6;         // [s]

// ---------------------------------------------------------------------
//  Pines (ESP32 DevKit clasico)
//    - Evitamos pines de arranque (0, 2, 5, 12, 15) y de flash (6-11)
//    - STBY del TB6612FNG queda conectado a HIGH por hardware.
// ---------------------------------------------------------------------
// CORRECCIÓN: A y B quedan invertidos respecto al base (A = 33, B = 32), como en
//             el banco; junto con la decodificacion de encoder_init() dan
//             velocidad positiva con PWM positivo
constexpr int PIN_ENC_A    = 33;   // encoder canal A
constexpr int PIN_ENC_B    = 32;   // encoder canal B
constexpr int PIN_PWMA     = 13;   // TB6612FNG PWMA: PWM
constexpr int PIN_AIN1     = 23;   // TB6612FNG AIN1: direccion
constexpr int PIN_AIN2     = 22;   // TB6612FNG AIN2: direccion
// Pines alternativos que ya se usaron en el banco:
// constexpr int PIN_ENC_A = 35;  PIN_ENC_B = 34;  PIN_PWMA = 18;  PIN_AIN1 = 21;  PIN_AIN2 = 19;

// ---------------------------------------------------------------------
//  Encoder y reductor
// ---------------------------------------------------------------------
constexpr double ENC_CPR_MOTOR = 64.0;   // cuentas/rev en el eje del MOTOR (16 x 4 flancos)
constexpr double GEAR_RATIO    = 50.0;   // relacion de reduccion
// constexpr float CPR_OUT = ENC_CPR_MOTOR * GEAR_RATIO;   // 3200 -> no se usa en este archivo
//                                                         (omega se mide en el eje del motor)
constexpr int    ENC_SIGN      = 1;      // pon -1 si con duty + la velocidad sale negativa
// ADICIÓN: filtro del PCNT como constante (en el base estaba fijo en 1000 = 12.5 us)
constexpr uint16_t ENC_FILTER  = 100;    // ciclos de APB (80 MHz) -> ignora pulsos < 1.25 us

// ADICIÓN: conversion de velocidad para la pagina
constexpr double KOUT = 60.0 / (2.0 * M_PI * GEAR_RATIO);   // rad/s motor -> RPM eje de salida

// ---------------------------------------------------------------------
//  PWM hacia el TB6612FNG: PWM en PWMA; AIN1/AIN2 seleccionan direccion
// ---------------------------------------------------------------------
constexpr uint32_t PWM_FREQ_HZ = 20000;  // 20 kHz (inaudible)
constexpr uint8_t  PWM_BITS    = 10;     // 0..1023
// ADICIÓN: canal LEDC (core 2.x) y voltaje de la fuente para pasar de % a V
constexpr uint8_t  PWM_CHANNEL = 0;
constexpr double   V_SUPPLY    = 12.0;   // [V]  ->  u[V] = duty[%] * V_SUPPLY / 100

// Limites de duty [%].
// ATENCION: limitar duty NO limita directamente la corriente del motor.
// A 50 % el arranque brusco seria ~ 6 V / 1.9 Ohm = 3.2 A (pico del TB6612FNG): por eso
// tambien hay rampa.
constexpr double MAX_DUTY_MANUAL = 50.0;   // [%] tope del comando de la pagina (+-)
// constexpr float MAX_DUTY_PROFILE = 50.0f;   -> no se usa en este archivo
// constexpr float MAX_DUTY_STREAM  = 50.0f;   -> no se usa en este archivo

// constexpr uint32_t MANUAL_TIMEOUT_MS = 60000;   -> no se usa en este archivo
//                       (el motor se detiene cuando no hay ninguna pagina conectada)

// ---------------------------------------------------------------------
//  Rampa del duty (limita la corriente de arranque y de frenado)
// ---------------------------------------------------------------------
// constexpr uint32_t WATCHDOG_MS     = 500;               -> no se usa en este archivo
// constexpr float    STREAM_MAX_DUTY = MAX_DUTY_STREAM;   -> no se usa en este archivo
constexpr double RAMP_PCT_PER_S = 150.0;   // [%/s] rampa maxima del duty
// ADICIÓN: modo al arrancar; se cambia desde la pagina (selector Ramp / Step)
constexpr bool   DEF_RAMP_ON    = true;    // true = rampa, false = escalon directo

// ---------------------------------------------------------------------
//  Perfil de prueba automatico (comando G)
// ---------------------------------------------------------------------
// struct Step { float dur_s; float duty_pct; };          -> no se usa en este archivo
// static const Step PROFILE[] = { {0.5f, 0.0f}, ... };   -> no se usa en este archivo
// constexpr size_t N_STEPS = ...;                         -> no se usa en este archivo

// ---------------------------------------------------------------------
//  ADICIÓN: modelo discreto del motor 2 (c2d, zoh, Ts = 0.008 s), bloque config.h del mlx
// ---------------------------------------------------------------------
constexpr double AD11 = -0.00656375526807087;
constexpr double AD12 = -0.0048629579529921;
constexpr double AD21 =  1.19105706241618;
constexpr double AD22 =  0.882426646325206;
constexpr double BD1  =  0.469957803662264;
constexpr double BD2  =  10.9368749012802;

// ---------------------------------------------------------------------
//  ADICIÓN: sintonia por defecto (tabla resumen del mlx, motor 2)
// ---------------------------------------------------------------------
constexpr double DEF_FAC  = 3.0;        // polos del observador 'fac' veces mas rapidos que la planta
constexpr double DEF_Q11  = 0.0001;     // [A^2]
// CORRECCIÓN: Q22 y R con los valores que imprime el mlx (antes 14.585 y 132.6)
constexpr double DEF_Q22  = 14.5854;    // [(rad/s)^2]
constexpr double DEF_R    = 132.603;    // [(rad/s)^2]
constexpr double DEF_P011 = 0.25;       // P0 = diag(0.5^2, 500^2), igual que en MATLAB
constexpr double DEF_P022 = 250000.0;
constexpr double DEF_PWM  = 30.0;       // [%] comando inicial de la pagina

// ADICIÓN: limites de fac aceptados desde la pagina (Notas 08: 2 a 4)
constexpr double FAC_MIN = 2.0;
constexpr double FAC_MAX = 4.0;

// ---------------------------------------------------------------------
//  ADICIÓN: Wi-Fi (punto de acceso). Pagina: http://192.168.4.1
// ---------------------------------------------------------------------
constexpr const char* WIFI_SSID = "Lab4-Observers";
// CORRECCIÓN: vacio = red ABIERTA (el comentario decia "al menos 8 caracteres")
constexpr const char* WIFI_PASS = "";

// ---------------------------------------------------------------------
//  ADICIÓN: tareas (core 1: control, core 0: Wi-Fi y pagina)
// ---------------------------------------------------------------------
constexpr int      CONTROL_CORE     = 1;
constexpr int      WEB_CORE         = 0;
constexpr int      CONTROL_PRIO     = 10;
constexpr int      WEB_PRIO         = 2;
constexpr int      SAMPLE_QUEUE_LEN = 256;
constexpr uint32_t WEB_PUSH_MS      = 50;     // periodo de envio por WebSocket
