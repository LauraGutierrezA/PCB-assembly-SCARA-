# Lab 4 – Luenberger observer + Kalman filter on ESP32 (motor 2)

- **Core 1** – control task every Ts = 8 ms (periodic `esp_timer`): encoder (PCNT, x4) → Luenberger predictor → Kalman filter → PWM to the TB6612FNG.
- **Core 0** – Wi-Fi access point, web page and WebSocket: inputs and live plots.

## Build and flash (PlatformIO)

1. Open the `lab4_observers` folder in VS Code with PlatformIO.
2. Upload: `pio run -t upload`, then open the monitor: `pio device monitor` (115200).
3. Connect to Wi-Fi **Lab4-Observers** (open network, no password) and open **http://192.168.4.1**.

The platform is pinned to `espressif32@6.9.0` (Arduino-ESP32 2.0.x). Do not move to core 3.x without porting `ledcSetup/ledcAttachPin` and the legacy PCNT driver.

## Files

| File | What it is |
|---|---|
| `include/config.h` | Pins, motor-2 `Ad`/`Bd`, default Q, R, fac, P0, PWM limit and ramp, Wi-Fi |
| `include/estimators.h`, `src/estimators.cpp` | Luenberger (Ackermann with z_obs = z_plant^fac) and Kalman, double precision |
| `src/main.cpp` | Tasks, encoder, PWM, web server, WebSocket |
| `web/index.html` | Dashboard source (MYCRON design system) |
| `tools/embed_page.py` | Rebuilds `include/web_page.h` after editing the page: `python tools/embed_page.py` |
| `test_host/test_estimators.cpp` | Checks the math against the MATLAB table, motor 2 (runs on a PC) |

## Before the first run

- **Encoder voltage:** check what voltage the encoder is powered from. Pins 32/33 accept 3.3 V only; if the encoder outputs are at 5 V you need a level shifter or a divider.
- **Direction:** if positive PWM gives negative speed, set `ENC_SIGN` to `-1` in `config.h`. Encoder pins are A = 33, B = 32 (swapped on purpose, matching the bench wiring).
- **STBY:** STBY is tied to 3.3 V in hardware (not driven by the ESP32).

## Notes

- The motor stops automatically (ramping down) when no page is connected.
- **PWM limit:** the command is limited to ±50 % and the applied duty follows a 150 %/s ramp or a direct step, selected live with the **Ramp / Step** switch on the page (`MAX_DUTY_MANUAL`, `RAMP_PCT_PER_S`, `DEF_RAMP_ON` in `config.h`; ramp is the default at power-up). The page marks a larger value in red and sends nothing until it is valid. At 0 % the driver is in short brake (V = 0).
- `Reset estimators` sets x̂ = 0 and P = P0 while the motor keeps running, so you can watch both estimators converge live.
- R defaults to the LabVIEW value of motor 2 (132.603). The ESP32 measures speed by counting pulses every 8 ms (one count ≈ 12.3 rad/s of motor speed), so the real noise can differ; tune R from the page.
- `Export CSV` saves the last 60 s of data in model units plus RPM at the output shaft.
