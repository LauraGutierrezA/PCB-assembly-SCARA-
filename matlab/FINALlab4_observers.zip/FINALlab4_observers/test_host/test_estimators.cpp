// =====================================================================
//  Prueba en el PC: compara la matematica del firmware con la tabla resumen del mlx.
//  CORRECCIÓN: motor 2 (antes motor 3), el mismo modelo de config.h
//  Compilar: g++ -std=c++17 -O2 -I../include test_estimators.cpp ../src/estimators.cpp -o t && ./t
// =====================================================================
#include <cstdio>
#include <cmath>
#include <initializer_list>
#include "estimators.h"

// Modelo discreto del motor 2 (bloque config.h del mlx, Ts = 0.008 s)
// (no se incluye config.h porque depende de Arduino.h)
static constexpr double AD11 = -0.00656375526807087;
static constexpr double AD12 = -0.0048629579529921;
static constexpr double AD21 =  1.19105706241618;
static constexpr double AD22 =  0.882426646325206;
static constexpr double BD1  =  0.469957803662264;
static constexpr double BD2  =  10.9368749012802;

// Sintonia del motor 2 (tabla resumen del mlx)
static constexpr double Q11 = 0.0001, Q22 = 14.5854, R = 132.603;

static int g_fails = 0;
static void check(const char* name, double got, double ref, double rel_tol) {
    const double rel = std::fabs(got - ref) / std::fmax(std::fabs(ref), 1e-30);
    const bool ok = rel <= rel_tol;
    if (!ok) ++g_fails;
    std::printf("%-28s got % .8g  ref % .8g  rel %.2e  %s\n", name, got, ref, rel, ok ? "OK" : "FAIL");
}

int main() {
    Model2 m{ { {AD11, AD12}, {AD21, AD22} }, {BD1, BD2} };

    // ---- Polos de la planta (mlx: eig(Ad) = [3.181507335e-08 0.8758628592]) ----
    LuenbergerDesign d = design_luenberger(m, 3.0);
    std::printf("design ok=%d err='%s'\n", d.ok, d.err);
    check("plant pole (large)", d.plant_re[0], 0.8758628592, 1e-8);
    // El polo pequeno sale de det(Ad) ~ 2.8e-8, una casi cancelacion
    check("plant pole (small)", d.plant_re[1], 3.181507335e-08, 2e-3);

    // ---- Luenberger L, fac = 3 (mlx: L = [-0.001124; 0.203957]) ----
    check("L1 (fac=3)", d.L[0], -0.001124,  1e-4);
    check("L2 (fac=3)", d.L[1],  0.203957,  1e-4);
    std::printf("observer poles: %.10g  %.10g\n", d.obs_re[0], d.obs_re[1]);

    // ---- Kalman en regimen permanente (tabla del mlx, motor 2) ----
    Kalman k; k.reset(0.25, 250000.0);
    for (int i = 0; i < 5000; ++i) k.step(m, Q11, Q22, R, 0.0, 0.0);
    check("K1 steady",   k.K[0],    -0.00072349, 1e-4);
    check("K2 steady",   k.K[1],     0.21737,    1e-4);
    check("P+11 steady", k.P[0][0],  0.00068685, 1e-4);
    check("P+22 steady", k.P[1][1],  28.824,     1e-4);
    check("P+12 steady", k.P[0][1], -0.095937,   1e-4);

    // ---- Convergencia: el modelo hace de planta, estimacion inicial equivocada (sim 1 del mlx) ----
    double x[2] = {0, 0}, y = 0, u = 12.0;
    Luenberger lu; lu.L[0] = d.L[0]; lu.L[1] = d.L[1]; lu.x[0] = 0.5; lu.x[1] = 500;
    Kalman kf; kf.reset(0.25, 250000.0); kf.x[0] = 0.5; kf.x[1] = 500;
    double y_prev = 0;
    for (int j = 1; j <= 63; ++j) {           // 0.5 s
        const double n0 = AD11 * x[0] + AD12 * x[1] + BD1 * u;
        const double n1 = AD21 * x[0] + AD22 * x[1] + BD2 * u;
        x[0] = n0; x[1] = n1; y = x[1];
        lu.step(m, y_prev, u);
        kf.step(m, Q11, Q22, R, u, y);
        y_prev = y;
    }
    std::printf("after 0.5 s: true i=%.5f w=%.3f | Luen i=%.5f w=%.3f | Kal i=%.5f w=%.3f\n",
                x[0], x[1], lu.x[0], lu.x[1], kf.x[0], kf.x[1]);
    check("Luenberger i converged", lu.x[0], x[0], 1e-3);
    check("Kalman i converged",     kf.x[0], x[0], 1e-3);

    // ---- Otros valores de fac deben seguir siendo validos ----
    for (double f : {1.0, 2.0, 4.0, 10.0}) {
        LuenbergerDesign dd = design_luenberger(m, f);
        std::printf("fac=%-4g ok=%d L=[%.6g; %.6g] poles=[%.4g %.4g]\n",
                    f, dd.ok, dd.L[0], dd.L[1], dd.obs_re[0], dd.obs_re[1]);
    }

    std::printf("\n%s (%d failures)\n", g_fails ? "SOME CHECKS FAILED" : "ALL CHECKS PASSED", g_fails);
    return g_fails ? 1 : 0;
}
