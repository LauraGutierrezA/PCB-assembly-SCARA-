classdef ESP32_IO < matlab.System & matlab.system.mixin.SampleTime
    % ESP32_IO  Bloque de Simulink (MATLAB System) = tarjeta de adquisicion.
    %
    %   Entrada : duty_cmd   [%]    duty pedido para el PWM del motor
    %   Salidas : omega      [rad/s] velocidad medida por el encoder
    %             Vmed       [V]     voltaje medido por el ADC (V(OUT1)-V(OUT2))
    %             duty_app   [%]     duty REALMENTE aplicado en el intervalo anterior
    %             perdidas           filas que faltaron desde el paso anterior
    %
    %   En cada paso: envia "D<duty>" a la ESP32 y espera la siguiente fila.
    %   Como espera el dato, la simulacion avanza al ritmo del reloj de la ESP32.
    %
    %   Lee del workspace base:  puerto, baud, Ts, duty_max
    %   Fila:  k,t_us,duty_prev,V_prev,omega,counts,mv1,mv2

    properties (Access = private)
        sp       = []
        kPrev    = -1
        dutyMax  = 90
    end

    methods (Access = protected)

        function setupImpl(obj)
            puerto  = evalin('base', 'puerto');
            baud    = evalin('base', 'baud');
            Ts_pc   = evalin('base', 'Ts');
            obj.dutyMax = evalin('base', 'duty_max');

            obj.sp = serialport(puerto, baud, 'Timeout', 3);
            configureTerminator(obj.sp, "LF");
            pause(2);                                   % la ESP32 se reinicia al abrir el puerto
            flush(obj.sp);
            writeline(obj.sp, "X"); pause(0.3); flush(obj.sp);
            writeline(obj.sp, "S");                     % modo continuo

            info = [];
            t0 = tic;
            while isempty(info)
                ln = readline(obj.sp);
                if ismissing(ln) || toc(t0) > 5
                    obj.sp = [];
                    error('ESP32_IO:sininfo', 'La ESP32 no respondio. Revisa el puerto, el firmware y que el monitor serie este cerrado.');
                end
                ln = strtrim(ln);
                if startsWith(ln, "#INFO")
                    info = sscanf(char(extractAfter(ln, "#INFO,")), '%f,%f,%f,%f');
                end
            end
            if abs(info(1)*1e-6 - Ts_pc) > 1e-9
                obj.sp = [];
                error('ESP32_IO:Ts', 'Ts del firmware (%.4f s) != Ts de MATLAB (%.4f s).', info(1)*1e-6, Ts_pc);
            end
            obj.kPrev = -1;
        end

        function [omega, Vmed, duty_app, perdidas] = stepImpl(obj, duty_cmd)
            d = min(max(double(duty_cmd), 0), obj.dutyMax);      % tope de seguridad tambien en el PC
            writeline(obj.sp, sprintf("D%.2f", d));

            if obj.sp.NumBytesAvailable > 4000                   % el PC se atraso: descartar lo acumulado
                flush(obj.sp, "input");
            end

            v = [];
            while numel(v) ~= 4
                ln = readline(obj.sp);

                if ismissing(ln)
                    error('ESP32_IO:timeout', 'La ESP32 dejo de enviar datos (o se activo el watchdog).');
                end

                ln = strtrim(ln);

                if startsWith(ln, "#")
                    if startsWith(ln, "#TIMEOUT") || startsWith(ln, "#STOP")
                        error('ESP32_IO:stop', 'La ESP32 detuvo el motor: %s', ln);
                    end
                    continue;
                end

                v = sscanf(char(ln), '%f,%f,%f,%f');
            end

            k = v(1);

            if obj.kPrev >= 0
                perdidas = max(0, k - obj.kPrev - 1);
            else
                perdidas = 0;
            end

            obj.kPrev = k;

            duty_app = v(3);
            omega    = v(4);
            Vmed     = NaN;
        end
        
        function resetImpl(obj)
            obj.kPrev = -1;
        end

        function releaseImpl(obj)
            if ~isempty(obj.sp)
                try
                    writeline(obj.sp, "D0"); pause(0.05);
                    writeline(obj.sp, "X");  pause(0.05);
                catch
                end
                obj.sp = [];                              % cierra el puerto
            end
        end

        % ---- Sample time ----
        function sts = getSampleTimeImpl(obj)
            sts = createSampleTime(obj, 'Type', 'Discrete', 'SampleTime', evalin('base', 'Ts'));
        end

        % ---- Tamanos y tipos (todo escalar double) ----
        function [s1, s2, s3, s4] = getOutputSizeImpl(~)
            s1 = [1 1]; s2 = [1 1]; s3 = [1 1]; s4 = [1 1];
        end
        function [d1, d2, d3, d4] = getOutputDataTypeImpl(~)
            d1 = "double"; d2 = "double"; d3 = "double"; d4 = "double";
        end
        function [c1, c2, c3, c4] = isOutputComplexImpl(~)
            c1 = false; c2 = false; c3 = false; c4 = false;
        end
        function [f1, f2, f3, f4] = isOutputFixedSizeImpl(~)
            f1 = true; f2 = true; f3 = true; f4 = true;
        end

        % ---- Etiquetas ----
        function icon = getIconImpl(~)
            icon = 'ESP32 I/O';
        end
        function name = getInputNamesImpl(~)
            name = 'duty_cmd';
        end
        function [n1, n2, n3, n4] = getOutputNamesImpl(~)
            n1 = 'omega'; n2 = 'Vmed'; n3 = 'duty_app'; n4 = 'perdidas';
        end
    end
end
