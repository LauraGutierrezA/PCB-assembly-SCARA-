%% =====================================================================
%  cargar_parametros_rt.m
%  Lo llama el modelo de Simulink (InitFcn) al abrirse/simular.
%  Carga parametros_motor + los .mat de diseno y deja en el workspace las
%  matrices que usan los bloques.
% =====================================================================
parametros_motor;

M_  = load('modelo_motor.mat');
Lu_ = load('luenberger.mat');
Ka_ = load('kalman.mat');

if any(abs([M_.Ts, Lu_.Ts, Ka_.Ts] - Ts) > 1e-12)
    error(['Ts en parametros_motor.m (%.4f s) no coincide con los .mat de diseno.\n' ...
           'Re-ejecuta paso1_modelo, paso2_luenberger y paso3_kalman.'], Ts);
end

Ad = M_.Ad;   Bd = M_.Bd;   Cd = M_.Cd;
L_luen = Lu_.L_luen;
L_kal  = Ka_.L_kal;

% Observadores en forma predictor:  p[k] = A_x*p[k-1] + B_x*[u[k-1]; y[k-1]]
A_luen = Ad - L_luen*Cd;   B_luen = [Bd, L_luen];
A_kal  = Ad - L_kal*Cd;    B_kal  = [Bd, L_kal];

x_mod0 = zeros(2,1);       % motor en reposo al iniciar

clear M_ Lu_ Ka_
