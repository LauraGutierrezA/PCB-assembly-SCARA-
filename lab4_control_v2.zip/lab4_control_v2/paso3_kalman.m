%% =====================================================================
%  PASO 3: Parametros del filtro de Kalman (ganancia de regimen permanente)
%
%  Modelo con ruido:   x[k+1] = Ad*x[k] + Bd*u[k] + w[k]     w ~ N(0, Qd)
%                      y[k]   = Cd*x[k] + v[k]               v ~ N(0, R)
%  Filtro (forma predictor, misma estructura que el Luenberger):
%      xhat[k] = Ad*xhat[k-1] + Bd*u[k-1] + L*( y[k-1] - Cd*xhat[k-1] )
%  con  L = Ad*P*Cd' / (Cd*P*Cd' + R),   P de la ecuacion de Riccati (dare).
%
%  Requiere: modelo_motor.mat (paso1).   Genera: kalman.mat
% =====================================================================
clear; clc; close all;
parametros_motor;
M = load('modelo_motor.mat');
if abs(M.Ts - Ts) > 1e-12, error('Ts de modelo_motor.mat no coincide con parametros_motor.m: re-ejecuta paso1_modelo.'); end
A = M.A;  B = M.B;  Ad = M.Ad;  Cd = M.Cd;  J = M.J;

%% ---------------------------------------------------------------------
%  1. RUIDO DE MEDICION R  (encoder)
%     Una cuenta del encoder en un periodo equivale a 'cuant' rad/s.
%     Ruido de cuantizacion uniforme: sigma = cuant/sqrt(12)
%     -> Despues mide la varianza real de omega en regimen y reemplaza sigma_w.
% ---------------------------------------------------------------------
cuant   = (2*pi/CPR_out)/Ts;     % [rad/s] por cuenta
sigma_w = cuant/sqrt(12);        % [rad/s]
R_meas  = sigma_w^2;

%% ---------------------------------------------------------------------
%  2. RUIDO DE PROCESO Q  (parametros de AJUSTE)
%     - ruido en el voltaje aplicado  (rizado de la fuente, caida del driver)
%     - perturbacion de torque        (rozamiento seco, carga no modelada)
%     Sigmas "por muestra"; la densidad espectral es sigma^2 * Ts.
% ---------------------------------------------------------------------
sigma_V = 0.10;      % [V]
sigma_T = 5e-4;      % [N*m]
G  = [B/Kd, [0; 1/J]];
Qw = diag([sigma_V^2, sigma_T^2]) * Ts;
Qc = G*Qw*G';

% Discretizacion exacta de Q:  Qd = P_inf - Ad*P_inf*Ad'  con  A*P + P*A' + Qc = 0
Pinf = lyap(A, Qc);
Qd   = Pinf - Ad*Pinf*Ad';
Qd   = (Qd + Qd')/2;
mn   = min(eig(Qd));
if mn <= 0, Qd = Qd + (abs(mn) + 1e-12)*eye(2); end

%% ---------------------------------------------------------------------
%  3. GANANCIA DE KALMAN (regimen permanente)
% ---------------------------------------------------------------------
[P, ~, ~] = dare(Ad', Cd', Qd, R_meas);   % P = covarianza a priori
S     = Cd*P*Cd' + R_meas;
L_kal = Ad*P*Cd'/S;                       % ganancia del predictor
M_kal = P*Cd'/S;                          % ganancia del filtro (informativa)

polos_kal = eig(Ad - L_kal*Cd);
fprintf('=== FILTRO DE KALMAN ===\n');
fprintf('Cuantizacion del encoder : %.4f rad/s por cuenta\n', cuant);
fprintf('sigma_w (medicion)       : %.4f rad/s  -> R = %.3g\n', sigma_w, R_meas);
fprintf('sigma_V, sigma_T         : %.3g V, %.3g N*m\n', sigma_V, sigma_T);
fprintf('Qd =\n'); disp(Qd);
fprintf('P (a priori) =\n'); disp(P);
fprintf('L_kal = [%.6g ; %.6g]\n', L_kal(1), L_kal(2));
fprintf('Polos de Ad - L*Cd       : %s\n', mat2str(polos_kal.', 5));
fprintf('Estable (|polos| < 1)    : %d\n', all(abs(polos_kal) < 1));
fprintf('Desviacion estandar a priori de omega: %.4f rad/s\n', sqrt(P(2,2)));
fprintf(['Interpretacion: si sigma_T o sigma_V suben, el filtro confia mas en la medicion\n' ...
         '(L crece y se parece al Luenberger rapido). Si bajan, filtra mas.\n']);

save('kalman.mat', 'L_kal', 'M_kal', 'P', 'Qd', 'R_meas', 'sigma_w', 'sigma_V', 'sigma_T', 'Ts');
disp('Guardado en kalman.mat');
