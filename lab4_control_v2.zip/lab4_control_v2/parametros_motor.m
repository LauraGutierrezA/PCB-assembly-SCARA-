%% =====================================================================
%  parametros_motor.m  -  UNICO lugar donde se editan los parametros
%  Todos los demas scripts y el modelo de Simulink llaman a este archivo.
%  Si cambias Ts: cambialo tambien en firmware (TS_US en config.h), vuelve a
%  subir el firmware y re-ejecuta paso1, paso2 y paso3.
% =====================================================================

%% --- Muestreo (intercambiable) ---------------------------------------
Ts = 0.008;          % [s]  (10 ms).  Debe coincidir con TS_US del firmware

%% --- Reductor y encoder ----------------------------------------------
N        = 50;       % relacion de reduccion
CPR_mot  = 64;       % cuentas/rev en el eje del MOTOR (16 pulsos/canal x 4 flancos)
CPR_out  = CPR_mot*N;% cuentas/rev en el eje de SALIDA (3200)

%% --- Parametros del MOTOR (medidos en el eje del motor, Lab III) ------
Ra     = 1.9;        % [Ohm]        resistencia de armadura
La     = 8.7398e-4;    % [H]          inductancia de armadura (valor poco fiable)
Kv     = 9.2306e-3;    % [V*s/rad]    constante de fcem
Kt_m   = Kv;         % [N*m/A]      constante de torque (en SI Kt = Kv)
beta_m = 1.4665e-6;   % [N*m*s/rad]  friccion viscosa
Jm     = 2.7440e-6;    % [kg*m^2]     inercia del rotor
eta    = 1.0;        % eficiencia del reductor (1 = ideal)

%% --- Del duty (%) al voltaje:   V = Kd * duty ------------------------
%  El modelo del motor trabaja en VOLTIOS, pero el slider y el PWM estan en %.
%  Kd es el factor de conversion. Ignorando la caida del driver:
Vfuente = 12;            % [V] voltaje de la fuente
Kd      = Vfuente/100;   % [V/%]  ->  0.12 V por cada 1 % de duty

%% --- Limites del slider ----------------------------------------------
duty_min = 20;       % [%]
duty_max = 50;       % [%]

%% --- Comunicacion serial con la ESP32 --------------------------------
puerto = "/dev/ttyUSB0";   % Windows: "COM3"
baud   = 921600;           % igual que SERIAL_BAUD en config.h
