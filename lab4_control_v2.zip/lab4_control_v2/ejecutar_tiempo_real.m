function ejecutar_tiempo_real()
% EJECUTAR_TIEMPO_REAL  Abre el modelo, muestra el panel con el slider de duty
% y arranca la simulacion en tiempo real (ESP32 -> Simulink).
%
%   Panel:  - Interruptor "Motor" (Off por defecto)
%           - Slider de duty [duty_min, duty_max] %
%   El valor se escribe en el bloque Duty_cmd mientras la simulacion corre.
%   Cierra el panel (o "Parar y cerrar") para detener el motor y la simulacion.

    evalin('base', 'cargar_parametros_rt;');
    dmin = evalin('base', 'duty_min');
    dmax = evalin('base', 'duty_max');
    Kd   = evalin('base', 'Kd');

    mdl = 'motor_observadores_tr';
    if ~bdIsLoaded(mdl), load_system(mdl); end
    open_system(mdl);
    set_param([mdl '/Duty_cmd'], 'Value', '0');

    fig = uifigure('Name', 'Control del motor', 'Position', [100 100 400 270]);
    uilabel(fig, 'Text', 'Duty cycle del PWM [%]', 'Position', [20 230 360 22], 'FontWeight', 'bold');
    sld = uislider(fig, 'Limits', [dmin dmax], 'Value', dmin, 'Position', [30 205 340 3], ...
                   'MajorTicks', dmin:10:dmax);
    lbl = uilabel(fig, 'Text', '', 'Position', [20 120 360 40], 'WordWrap', 'on');
    uilabel(fig, 'Text', 'Motor', 'Position', [20 70 60 22]);
    sw  = uiswitch(fig, 'toggle', 'Position', [90 62 40 20]);
    uibutton(fig, 'Text', 'Parar y cerrar', 'Position', [250 20 130 30], ...
             'ButtonPushedFcn', @(~,~) cerrar());

    sld.ValueChangingFcn = @(~, e) aplicar(e.Value);
    sld.ValueChangedFcn  = @(s, ~) aplicar(s.Value);
    sw.ValueChangedFcn   = @(~, ~) aplicar(sld.Value);
    fig.CloseRequestFcn  = @(~, ~) cerrar();

    aplicar(sld.Value);
    set_param(mdl, 'SimulationCommand', 'start');

    function aplicar(v)
        if strcmp(sw.Value, 'On'), d = v; else, d = 0; end
        try, set_param([mdl '/Duty_cmd'], 'Value', sprintf('%.2f', d)); catch, end
        lbl.Text = sprintf('Duty pedido: %.1f %%   ->   u = Kd*duty = %.2f V\n(el firmware aplica una rampa de subida)', d, Kd*d);
    end

    function cerrar()
        try, set_param(mdl, 'SimulationCommand', 'stop'); catch, end
        if isvalid(fig), delete(fig); end
    end
end
