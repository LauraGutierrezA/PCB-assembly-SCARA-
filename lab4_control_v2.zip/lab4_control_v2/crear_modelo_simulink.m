%% =====================================================================
%  crear_modelo_simulink.m
%  Construye UN SOLO modelo de Simulink, motor_observadores_tr.slx, con:
%     - ESP32_IO         : lee omega, Vmed y duty aplicado; envia el duty pedido
%     - Kd               : duty [%] -> voltaje [V]   (u = Kd * duty)
%     - Modelo del motor : x[k] = Ad x[k-1] + Bd u[k-1]
%     - Observador de Luenberger y Filtro de Kalman (forma predictor)
%     - Scopes de omega, corriente y diagnostico
%  Requisitos: parametros_motor.m, paso1, paso2, paso3 ya ejecutados;
%              ESP32_IO.m en la misma carpeta.
% =====================================================================
clear; clc; close all;
cargar_parametros_rt;               % deja Ad, Bd, A_luen, B_luen, A_kal, B_kal, Kd, Ts ... en el workspace

mdl = 'motor_observadores_tr';
if bdIsLoaded(mdl), close_system(mdl, 0); end
new_system(mdl);
open_system(mdl);
set_param(mdl, 'InitFcn', 'cargar_parametros_rt;');

%% ---------------------------------------------------------------------
%  Bloques
% ---------------------------------------------------------------------
addb(mdl,'Duty_cmd','simulink/Sources/Constant',[30 70 100 100],'Value','0');

addb(mdl,'ESP32_IO','simulink/User-Defined Functions/MATLAB System',[160 40 280 170]);
set_param([mdl '/ESP32_IO'], 'System', 'ESP32_IO');
try, set_param([mdl '/ESP32_IO'], 'SimulateUsing', 'Interpreted execution'); catch, end

addb(mdl,'Kd','simulink/Math Operations/Gain',[350 220 410 250],'Gain','Kd');
addb(mdl,'y_prev','simulink/Discrete/Unit Delay',[350 100 400 130], ...
     'InitialCondition','0','SampleTime','Ts');
addb(mdl,'Mux_uy','simulink/Signal Routing/Mux',[470 190 475 270],'Inputs','2');

addb(mdl,'Modelo','simulink/Discrete/Discrete State-Space',[560 330 700 390], ...
     'A','Ad','B','Bd','C','Ad','D','Bd','X0','x_mod0','SampleTime','Ts');
addb(mdl,'Luenberger','simulink/Discrete/Discrete State-Space',[560 190 700 250], ...
     'A','A_luen','B','B_luen','C','A_luen','D','B_luen','X0','[0;0]','SampleTime','Ts');
addb(mdl,'Kalman','simulink/Discrete/Discrete State-Space',[560 440 700 500], ...
     'A','A_kal','B','B_kal','C','A_kal','D','B_kal','X0','[0;0]','SampleTime','Ts');

addb(mdl,'Demux_mod','simulink/Signal Routing/Demux',[760 335 765 385],'Outputs','2');
addb(mdl,'Demux_luen','simulink/Signal Routing/Demux',[760 195 765 245],'Outputs','2');
addb(mdl,'Demux_kal','simulink/Signal Routing/Demux',[760 445 765 495],'Outputs','2');

addb(mdl,'mA_mod','simulink/Math Operations/Gain',[820 330 870 360],'Gain','1000');
addb(mdl,'mA_luen','simulink/Math Operations/Gain',[820 190 870 220],'Gain','1000');
addb(mdl,'mA_kal','simulink/Math Operations/Gain',[820 440 870 470],'Gain','1000');

addb(mdl,'Scope_omega','simulink/Sinks/Scope',[960 60 1000 140],'NumInputPorts','4');
addb(mdl,'Scope_i','simulink/Sinks/Scope',[960 260 1000 340],'NumInputPorts','3');
addb(mdl,'Scope_diag','simulink/Sinks/Scope',[960 520 1000 600],'NumInputPorts','3');

addb(mdl,'Mux_log','simulink/Signal Routing/Mux',[960 380 965 480],'Inputs','9');
addb(mdl,'ToWS_log','simulink/Sinks/To Workspace',[1040 415 1120 445], ...
     'VariableName','log_rt','SaveFormat','Timeseries');

%% ---------------------------------------------------------------------
%  Conexiones
% ---------------------------------------------------------------------
ln(mdl,'Duty_cmd/1','ESP32_IO/1','duty pedido');

ln(mdl,'ESP32_IO/1','y_prev/1','omega medida');
ln(mdl,'ESP32_IO/1','Scope_omega/1','omega medida');
ln(mdl,'ESP32_IO/1','Mux_log/1','omega medida');

ln(mdl,'ESP32_IO/2','Scope_diag/1','V medido (ADC)');
ln(mdl,'ESP32_IO/2','Mux_log/9','V medido (ADC)');
ln(mdl,'ESP32_IO/4','Scope_diag/3','filas perdidas');

% Duty realmente aplicado por la ESP32
ln(mdl,'ESP32_IO/3','Mux_log/8','duty aplicado [%]');

% Entrada directa a los modelos
ln(mdl,'ESP32_IO/3','Mux_uy/1','duty aplicado [%]');
ln(mdl,'ESP32_IO/3','Modelo/1','duty aplicado [%]');

% Conversion solamente para diagnostico
ln(mdl,'ESP32_IO/3','Kd/1','duty aplicado [%]');
ln(mdl,'Kd/1','Scope_diag/2','voltaje equivalente estimado [V]');
ln(mdl,'y_prev/1','Mux_uy/2','y[k-1]');
ln(mdl,'Mux_uy/1','Luenberger/1','');
ln(mdl,'Mux_uy/1','Kalman/1','');

ln(mdl,'Modelo/1','Demux_mod/1','');
ln(mdl,'Luenberger/1','Demux_luen/1','');
ln(mdl,'Kalman/1','Demux_kal/1','');

% omega (salida 2 de cada demux)
ln(mdl,'Demux_mod/2','Scope_omega/2','omega modelo');
ln(mdl,'Demux_luen/2','Scope_omega/3','omega Luenberger');
ln(mdl,'Demux_kal/2','Scope_omega/4','omega Kalman');
ln(mdl,'Demux_mod/2','Mux_log/2','omega modelo');
ln(mdl,'Demux_luen/2','Mux_log/3','omega Luenberger');
ln(mdl,'Demux_kal/2','Mux_log/4','omega Kalman');

% corriente (salida 1 de cada demux)
ln(mdl,'Demux_mod/1','mA_mod/1','');
ln(mdl,'Demux_luen/1','mA_luen/1','');
ln(mdl,'Demux_kal/1','mA_kal/1','');
ln(mdl,'mA_mod/1','Scope_i/1','i modelo [mA]');
ln(mdl,'mA_luen/1','Scope_i/2','i Luenberger [mA]');
ln(mdl,'mA_kal/1','Scope_i/3','i Kalman [mA]');
ln(mdl,'Demux_mod/1','Mux_log/5','i modelo [A]');
ln(mdl,'Demux_luen/1','Mux_log/6','i Luenberger [A]');
ln(mdl,'Demux_kal/1','Mux_log/7','i Kalman [A]');

ln(mdl,'Mux_log/1','ToWS_log/1','');

%% ---------------------------------------------------------------------
%  Solver y leyendas de los scopes
% ---------------------------------------------------------------------
set_param(mdl, 'SolverType','Fixed-step', 'Solver','FixedStepDiscrete', ...
               'FixedStep','Ts', 'StopTime','inf');

nombres = {'Scope_omega','Scope_i','Scope_diag'};
for j = 1:numel(nombres)
    try
        cfg = get_param([mdl '/' nombres{j}], 'ScopeConfiguration');
        cfg.ShowLegend = true;
    catch
    end
end

save_system(mdl);
fprintf('Modelo creado: %s.slx\n', mdl);
fprintf('Orden de columnas de log_rt: [omega_med omega_mod omega_luen omega_kal i_mod i_luen i_kal duty_app Vmed]\n');
fprintf('Para correrlo con el slider:  ejecutar_tiempo_real\n');

%% ---------------------------------------------------------------------
function addb(mdl, name, lib, pos, varargin)
    add_block(lib, [mdl '/' name], 'Position', pos, varargin{:});
end

function ln(mdl, src, dst, nombre)
    h = add_line(mdl, src, dst, 'autorouting', 'on');
    if ~isempty(nombre), set_param(h, 'Name', nombre); end
end
