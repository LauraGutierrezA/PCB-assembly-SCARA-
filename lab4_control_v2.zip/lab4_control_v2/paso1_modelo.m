%% =====================================================================
%  PASO 1: Modelo del motor DC en espacio de estados
%          + Controlabilidad y Observabilidad
%  Entrada: voltaje V [V]   |   Estados: x = [i (A); omega (rad/s)]
%  Salida medida: omega (velocidad del eje de SALIDA)
%  Genera: modelo_motor.mat
% =====================================================================
clear; clc; close all;
parametros_motor;      % Ts, N, CPR_out, Ra, La, Kv, beta_m, Jm, Kd, ...

%% ---------------------------------------------------------------------
%  1. PARAMETROS REFERIDOS AL EJE DE SALIDA
%     omega_mot = N*omega   ->   Ke = N*Kv,  Kt = N*Kt_m,  J = N^2*Jm,  b = N^2*beta_m
% ---------------------------------------------------------------------
R  = Ra;
L  = La;
Ke = N*Kv;
Kt = N*Kt_m*eta;
J  = N^2*Jm;
b  = N^2*beta_m;

%% ---------------------------------------------------------------------
%  2. ECUACIONES Y ESPACIO DE ESTADOS
%     L*di/dt     = V - R*i - Ke*omega
%     J*domega/dt = Kt*i - b*omega
% ---------------------------------------------------------------------
A = [ -R/L   -Ke/L ;
       Kt/J  -b/J  ];
B = [ Kd/L ;
      0   ];
C = [ 0  1 ];          % solo se mide la velocidad
D = 0;

sys_c = ss(A, B, C, D, 'StateName', {'i [A]','omega [rad/s]'}, ...
           'InputName', {'Duty [%]'}, 'OutputName', {'omega [rad/s]'});

disp('=== Modelo continuo (A, B, C, D) ===');
A, B, C, D %#ok<NOPTS>

%% ---------------------------------------------------------------------
%  3. DISCRETIZACION (ZOH) con Ts
% ---------------------------------------------------------------------
sys_d = c2d(sys_c, Ts, 'zoh');
[Ad, Bd, Cd, Dd] = ssdata(sys_d);

fprintf('=== Modelo discreto (ZOH), Ts = %.4f s ===\n', Ts);
Ad, Bd, Cd, Dd %#ok<NOPTS>

%% ---------------------------------------------------------------------
%  4. POLOS
% ---------------------------------------------------------------------
polos_c = eig(A);
polos_d = eig(Ad);
disp('Polos continuos:'); disp(polos_c);
disp('Polos discretos :'); disp(polos_d);
fprintf('Constante de tiempo electrica ~ %.2f ms\n', 1e3/abs(min(real(polos_c))));
fprintf('Constante de tiempo mecanica  ~ %.2f ms\n', 1e3/abs(max(real(polos_c))));

%% ---------------------------------------------------------------------
%  5. CONTROLABILIDAD Y OBSERVABILIDAD
% ---------------------------------------------------------------------
n = size(A,1);
rc_c = rank(ctrb(A,B));   rc_d = rank(ctrb(Ad,Bd));
ro_c = rank(obsv(A,C));   ro_d = rank(obsv(Ad,Cd));

fprintf('\n=== CONTROLABILIDAD ===\n');
fprintf('Continuo: rango %d de %d -> %s\n', rc_c, n, ternario(rc_c==n,'CONTROLABLE','NO controlable'));
fprintf('Discreto: rango %d de %d -> %s\n', rc_d, n, ternario(rc_d==n,'CONTROLABLE','NO controlable'));
fprintf('\n=== OBSERVABILIDAD (y = omega) ===\n');
fprintf('Continuo: rango %d de %d -> %s\n', ro_c, n, ternario(ro_c==n,'OBSERVABLE','NO observable'));
fprintf('Discreto: rango %d de %d -> %s\n', ro_d, n, ternario(ro_d==n,'OBSERVABLE','NO observable'));
fprintf('cond(obsv discreto) = %.3g\n', cond(obsv(Ad,Cd)));

%% ---------------------------------------------------------------------
%  6. VERIFICACION: escalon de voltaje equivalente a duty = 50 %  (V = Kd*50)
% ---------------------------------------------------------------------
duty_prueba = 50;
V_prueba = Kd*duty_prueba;
t = 0:Ts:1;
[y, ~, x] = step(duty_prueba*sys_c, t);

figure('Name','Paso 1: respuesta al escalon');
subplot(2,1,1); plot(t, y, 'LineWidth',1.5); grid on;
ylabel('\omega [rad/s]'); title(sprintf('Escalon de %.1f V (duty 50 %%, modelo)', V_prueba));
subplot(2,1,2); plot(t, x(:,1)*1000, 'LineWidth',1.5); grid on;
ylabel('i [mA]'); xlabel('t [s]');

fprintf('\nA duty 50 %% (%.1f V): omega en regimen = %.1f rad/s (%.0f rpm), i = %.0f mA, pico = %.2f A\n', ...
        V_prueba, y(end), y(end)*60/(2*pi), x(end,1)*1000, max(x(:,1)));
fprintf('A duty %d %% (%.1f V) el pico de corriente al arrancar BRUSCAMENTE seria %.1f A: por eso el firmware aplica rampa.\n', ...
        duty_max, Kd*duty_max, Kd*duty_max/R);

%% ---------------------------------------------------------------------
save('modelo_motor.mat','A','B','C','D','Ad','Bd','Cd','Dd','Ts','Kd', ...
     'R','L','Ke','Kt','J','b','N','CPR_out','sys_c','sys_d');
disp('Modelo guardado en modelo_motor.mat');

function s = ternario(c, a, b)
    if c, s = a; else, s = b; end
end
