%% =====================================================================
%  PASO 2: Parametros del observador de Luenberger (forma PREDICTOR)
%
%     xhat[k] = Ad*xhat[k-1] + Bd*u[k-1] + L*( y[k-1] - Cd*xhat[k-1] )
%
%  Error:  e[k] = (Ad - L*Cd) * e[k-1]   ->  L se elige para colocar los polos
%  Requiere: modelo_motor.mat (paso1).   Genera: luenberger.mat
% =====================================================================
clear; clc; close all;
parametros_motor;
M = load('modelo_motor.mat');
if abs(M.Ts - Ts) > 1e-12, error('Ts de modelo_motor.mat no coincide con parametros_motor.m: re-ejecuta paso1_modelo.'); end

%% ---------------------------------------------------------------------
%  Parametros de diseno (editables)
% ---------------------------------------------------------------------
k_obs = 3;       % el observador es k_obs veces mas rapido que el polo mecanico
sep   = 1.2;     % separacion entre los 2 polos (place no admite polos repetidos)

%% ---------------------------------------------------------------------
%  Diseno por ubicacion de polos (dualidad: place(Ad', Cd', polos)' )
% ---------------------------------------------------------------------
w_lento  = min(abs(real(eig(M.A))));        % polo mecanico [rad/s]
polos_c  = -k_obs*w_lento*[1; sep];         % polos deseados continuos
polos_z  = exp(polos_c*Ts);                 % al plano z

L_luen = place(M.Ad', M.Cd', polos_z)';

polos_lazo = eig(M.Ad - L_luen*M.Cd);
fprintf('=== OBSERVADOR DE LUENBERGER ===\n');
fprintf('Polo mecanico de la planta    : %.1f rad/s\n', w_lento);
fprintf('Polos deseados (s)            : %s\n', mat2str(polos_c.', 5));
fprintf('Polos deseados (z)            : %s\n', mat2str(polos_z.', 5));
fprintf('Polos reales de Ad - L*Cd     : %s\n', mat2str(polos_lazo.', 5));
fprintf('Estable (|polos| < 1)         : %d\n', all(abs(polos_lazo) < 1));
fprintf('L = [%.6g ; %.6g]   (L(1): corriente [A], L(2): velocidad)\n', L_luen(1), L_luen(2));

if any(abs(polos_z) < 1e-2)
    fprintf(['Aviso: polos casi en z = 0 (observador tipo deadbeat): amplifica el ruido.\n' ...
             '       Baja k_obs si el ruido de la estimacion es excesivo.\n']);
end

save('luenberger.mat', 'L_luen', 'k_obs', 'sep', 'polos_z', 'Ts');
disp('Guardado en luenberger.mat');
