// =====================================================================
//  config.h - TODO lo editable del firmware esta aqui
//  Motor: Pololu 37D 50:1 12 V, encoder 64 CPR | Driver: TB6612FNG
// =====================================================================
#pragma once
#include <Arduino.h>

// ---------------------------------------------------------------------
//  Comunicacion serial (debe coincidir con MATLAB y con monitor_speed)
// ---------------------------------------------------------------------
#define SERIAL_BAUD 921600

// ---------------------------------------------------------------------
//  Muestreo. Debe ser IGUAL al Ts usado en MATLAB (modelo_motor.mat).
//  Ts = 10000 us equivale a una frecuencia de muestreo de 100 Hz.
// ---------------------------------------------------------------------
constexpr uint32_t TS_US = 8000;          // [us]  10 ms

// ---------------------------------------------------------------------
//  Pines (ESP32 DevKit clasico)
//    - Evitamos pines de arranque (0, 2, 5, 12, 15) y de flash (6-11)
//    - STBY del TB6612FNG queda conectado a HIGH por hardware.
//    - Las señales de PWM/direccion y encoder pasan por optoacopladores.
// ---------------------------------------------------------------------
constexpr int PIN_ENC_A    = 32;   // encoder canal A (amarillo)
constexpr int PIN_ENC_B    = 33;   // encoder canal B (blanco)
constexpr int PIN_PWMA     = 13;   // TB6612FNG PWMA: PWM por optoacoplador
constexpr int PIN_AIN1     = 23;   // TB6612FNG AIN1: direccion por optoacoplador
constexpr int PIN_AIN2     = 22;   // TB6612FNG AIN2: direccion por optoacoplador

// ---------------------------------------------------------------------
//  Encoder y reductor (igual que en el script del Paso 1)
// ---------------------------------------------------------------------
constexpr float ENC_CPR_MOTOR = 64.0f;   // cuentas/rev en el eje del MOTOR (4x)
constexpr float GEAR_RATIO    = 50.0f;   // verifica la relacion real en la ficha de Pololu
constexpr float CPR_OUT       = ENC_CPR_MOTOR * GEAR_RATIO;   // 3200
constexpr int   ENC_SIGN      = 1;       // pon -1 si con duty + la velocidad sale negativa

// ---------------------------------------------------------------------
//  PWM hacia el TB6612FNG: PWM en PWMA; AIN1/AIN2 seleccionan direccion
// ---------------------------------------------------------------------
constexpr uint32_t PWM_FREQ_HZ = 20000;  // 20 kHz (inaudible)
constexpr uint8_t  PWM_BITS    = 10;     // 0..1023

// Limites de duty [%].
// ATENCION: limitar duty NO limita directamente la corriente del motor.
// Verifica la corriente de bloqueo del motor y la capacidad termica del TB6612FNG.
constexpr float MAX_DUTY_PROFILE = 50.0f;
constexpr float MAX_DUTY_MANUAL  = 50.0f;
constexpr float MAX_DUTY_STREAM  = 50.0f;

// En modo manual (comando D) el motor se detiene solo si no llegan comandos.
constexpr uint32_t MANUAL_TIMEOUT_MS = 60000;

// ---------------------------------------------------------------------
//  Modo STREAM (comando S): adquisicion continua gobernada desde Simulink
// ---------------------------------------------------------------------
constexpr uint32_t WATCHDOG_MS     = 500;    // sin comando D en este tiempo -> el motor se detiene
constexpr float    STREAM_MAX_DUTY = MAX_DUTY_STREAM; // [%] tope de duty en modo stream
constexpr float    RAMP_PCT_PER_S  = 150.0f; // [%/s] rampa maxima del duty (limita la corriente de arranque)

// ---------------------------------------------------------------------
//  Perfil de prueba automatico (comando G):  {duracion [s], duty [%]}
//  Los duty se recortan a +-MAX_DUTY_PROFILE.
//  Duraciones multiplos de Ts.
// ---------------------------------------------------------------------
struct Step { float dur_s; float duty_pct; };
//  Perfil conservador para pruebas iniciales con el TB6612FNG.
//  Verifica la corriente del motor antes de aumentar estos valores.
static const Step PROFILE[] = {
    {0.5f,   0.0f},
    {2.0f,  25.0f},
    {2.0f,  50.0f},
    {2.0f,  30.0f},
    {1.0f,   0.0f},
    {2.0f,  40.0f},
    {1.0f,   0.0f},
};
constexpr size_t N_STEPS = sizeof(PROFILE) / sizeof(PROFILE[0]);
