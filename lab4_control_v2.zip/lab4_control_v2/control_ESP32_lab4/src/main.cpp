// =====================================================================
//  Adquisicion de datos - Motor DC Pololu 37D 50:1 con ESP32 + TB6612FNG
//
//  Que hace:
//   1. Genera PWM sobre PWMA; AIN1/AIN2 seleccionan el sentido de giro.
//   2. Cuenta el encoder en cuadratura x4 con el periferico PCNT (hardware).
//   3. Cada Ts calcula omega [rad/s] en el eje de SALIDA.
//   4. Envia PWM aplicado y velocidad angular por Serial; no mide tension.
//
//  Comandos (ASCII, terminados en \n):
//    G        ejecuta el perfil de prueba definido en config.h
//    S        adquisicion continua (Simulink). Luego enviar D<val> en cada ciclo;
//             si dejan de llegar comandos D durante WATCHDOG_MS el motor se detiene
//    X        detiene el motor y termina
//    D<val>   modo manual, duty solicitado en % (se limita a +-MAX_DUTY_MANUAL). Ej: D30
//    I        imprime informacion
//
//  Formato de datos: k,t_us,pwm_prev,omega
//   pwm_prev: duty firmado [%] aplicado durante el intervalo que acaba de terminar.
//   omega: velocidad angular medida durante ese intervalo [rad/s], eje de salida.
//   En MATLAB: usar pwm_prev como entrada u y omega como salida y, alineando
//   cada muestra con el intervalo correspondiente.
// =====================================================================
#include <Arduino.h>
#include "driver/pcnt.h"
#include "esp_timer.h"
#include "config.h"

enum Mode : uint8_t { MODE_IDLE, MODE_PROFILE, MODE_MANUAL, MODE_STREAM };

static Mode               g_mode  = MODE_IDLE;
static esp_timer_handle_t g_timer = nullptr;
static TaskHandle_t       g_task  = nullptr;
static volatile uint32_t  g_tick_count = 0;   // lo incrementa el timer
static uint32_t           g_missed = 0;       // ciclos perdidos (sobrecarga)

static bool     g_first = true;
static int64_t  g_t0 = 0, g_t_prev = 0;
static float    g_manual_duty = 0.0f;   // duty pedido (objetivo)
static float    g_duty_cur    = 0.0f;   // duty aplicado (despues de la rampa)
static uint32_t g_last_cmd_ms = 0;

// Medidas del intervalo anterior (se imprimen en la fila siguiente)
static float g_prev_duty = 0.0f;

// ---------------------------------------------------------------------
//  PWM / motor: PWM por PWMA; AIN1 y AIN2 son digitales para direccion
// ---------------------------------------------------------------------
constexpr uint32_t PWM_MAX = (1u << PWM_BITS) - 1;

static void pwm_init() {
    pinMode(PIN_AIN1, OUTPUT);
    pinMode(PIN_AIN2, OUTPUT);

    digitalWrite(PIN_AIN1, LOW);
    digitalWrite(PIN_AIN2, LOW);

#if ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcAttach(PIN_PWMA, PWM_FREQ_HZ, PWM_BITS);
    ledcWrite(PIN_PWMA, 0);
#else
    ledcSetup(0, PWM_FREQ_HZ, PWM_BITS);
    ledcAttachPin(PIN_PWMA, 0);
    ledcWrite(0, 0);
#endif
}

// Escribe el duty PWM en PWMA (0..PWM_MAX).
static void pwm_write(uint32_t duty) {
    duty = min(duty, PWM_MAX);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
    ledcWrite(PIN_PWMA, duty);
#else
    ledcWrite(0, duty);
#endif
}

// duty en % (-100..100).
// PWMA recibe PWM; AIN1/AIN2 solo seleccionan el sentido.
// STBY debe estar en HIGH por hardware para habilitar el TB6612FNG.
// Con duty = 0, PWMA queda en LOW y no se aplica potencia al motor.
static void motor_set(float duty) {
    duty = fminf(100.0f, fmaxf(-100.0f, duty));

    const uint32_t pwm_value =
        (uint32_t)(fabsf(duty) / 100.0f * PWM_MAX + 0.5f);

    // Desactiva PWMA antes de cambiar la direccion para evitar un pulso
    // momentaneo de potencia durante una inversion de giro.
    pwm_write(0);

    if (duty > 0.0f) {
        digitalWrite(PIN_AIN1, HIGH);
        digitalWrite(PIN_AIN2, LOW);
    } else if (duty < 0.0f) {
        digitalWrite(PIN_AIN1, LOW);
        digitalWrite(PIN_AIN2, HIGH);
    } else {
        // PWM en LOW deja de aplicar potencia al motor.
        pwm_write(0);
        digitalWrite(PIN_AIN1, LOW);
        digitalWrite(PIN_AIN2, LOW);
        return;
    }

    pwm_write(pwm_value);
}

// ---------------------------------------------------------------------
//  Encoder en cuadratura x4 con PCNT
// ---------------------------------------------------------------------
static const pcnt_unit_t PCNT_U = PCNT_UNIT_0;
static int16_t g_last_cnt = 0;

static void encoder_init() {
    pinMode(PIN_ENC_A, INPUT_PULLUP);
    pinMode(PIN_ENC_B, INPUT_PULLUP);

    pcnt_config_t c = {};
    c.unit = PCNT_U;
    c.counter_h_lim = 32767;
    c.counter_l_lim = -32768;

    // Canal 0: pulso = A, control = B
    c.channel = PCNT_CHANNEL_0;
    c.pulse_gpio_num = PIN_ENC_A;  c.ctrl_gpio_num = PIN_ENC_B;
    c.pos_mode = PCNT_COUNT_INC;   c.neg_mode = PCNT_COUNT_DEC;
    c.lctrl_mode = PCNT_MODE_KEEP; c.hctrl_mode = PCNT_MODE_REVERSE;
    pcnt_unit_config(&c);

    // Canal 1: pulso = B, control = A  (completa los 4 flancos)
    c.channel = PCNT_CHANNEL_1;
    c.pulse_gpio_num = PIN_ENC_B;  c.ctrl_gpio_num = PIN_ENC_A;
    c.pos_mode = PCNT_COUNT_INC;   c.neg_mode = PCNT_COUNT_DEC;
    c.lctrl_mode = PCNT_MODE_REVERSE; c.hctrl_mode = PCNT_MODE_KEEP;
    pcnt_unit_config(&c);

    pcnt_set_filter_value(PCNT_U, 1000);   // ignora pulsos < 12.5 us (rebotes/ruido)
    pcnt_filter_enable(PCNT_U);

    pcnt_counter_pause(PCNT_U);
    pcnt_counter_clear(PCNT_U);
    pcnt_counter_resume(PCNT_U);
}

static void encoder_reset() {
    pcnt_counter_clear(PCNT_U);
    g_last_cnt = 0;
}

// Devuelve las cuentas nuevas desde la ultima llamada.
// El contador es de 16 bits: lo borramos antes de que se acerque al limite.
static int32_t encoder_update() {
    int16_t v = 0;
    pcnt_get_counter_value(PCNT_U, &v);
    int32_t d = (int32_t)v - (int32_t)g_last_cnt;
    g_last_cnt = v;
    if (v > 20000 || v < -20000) {          // ocurre cada >1.5 s a maxima velocidad
        pcnt_counter_clear(PCNT_U);
        g_last_cnt = 0;
    }
    return d;
}

// ---------------------------------------------------------------------
//  Salida serial
// ---------------------------------------------------------------------
static float profile_total_s() {
    float t = 0;
    for (size_t i = 0; i < N_STEPS; i++) t += PROFILE[i].dur_s;
    return t;
}

static void print_info() {
    Serial.printf("#COLS,k,t_us,pwm_prev,omega\n");
    Serial.printf("#INFO,%lu,%.1f,%lu,%.3f\n",
                  (unsigned long)TS_US, CPR_OUT, (unsigned long)PWM_FREQ_HZ, profile_total_s());
}

static void print_row(uint32_t k, int64_t t_us, float omega) {
    char buf[80];
    int n = snprintf(buf, sizeof(buf), "%lu,%lld,%.1f,%.4f\n",
                     (unsigned long)k, (long long)t_us, g_prev_duty, omega);
    if (n > 0) Serial.write((const uint8_t*)buf, (size_t)n);
}

// ---------------------------------------------------------------------
//  Control de la ejecucion
// ---------------------------------------------------------------------
static void tick_cb(void*) {
    g_tick_count = g_tick_count + 1;
    xTaskNotifyGive(g_task);
}

static void start_run(Mode m) {
    g_mode = m;
    g_first = true;
    g_missed = 0;
    g_tick_count = 0;
    g_prev_duty = 0.0f;
    g_duty_cur = 0.0f;
    g_last_cmd_ms = millis();
    encoder_reset();
    motor_set(0);
    print_info();
    ulTaskNotifyTake(pdTRUE, 0);                    // descarta avisos viejos
    esp_timer_start_periodic(g_timer, TS_US);       // el primer tick (k=0) llega en Ts
}

static void stop_run(const char* tag) {
    esp_timer_stop(g_timer);
    motor_set(0);                   // PWMA = 0: deja de aplicar potencia al motor
    g_duty_cur = 0.0f;
    g_mode = MODE_IDLE;
    Serial.printf("%s,%lu\n", tag, (unsigned long)g_missed);
}

// Se ejecuta una vez por periodo Ts
static void do_tick() {
    const int64_t  now = esp_timer_get_time();
    const uint32_t k   = g_tick_count - 1;

    // 1) Velocidad: lo PRIMERO es leer el encoder (instante de muestreo exacto)
    float omega = 0.0f;
    if (g_first) {
        g_first = false;
        g_t0 = now;  g_t_prev = now;
        encoder_reset();
    } else {
        const int32_t d  = encoder_update();
        const float   dt = (float)(now - g_t_prev) * 1e-6f;   // dt real medido
        omega = (float)ENC_SIGN * (float)d * (TWO_PI / CPR_OUT) / dt;
        g_t_prev = now;
    }

    // 2) Enviar la fila k (omega medida + PWM del intervalo anterior)
    print_row(k, now - g_t0, omega);

    // 3) Decidir el duty del proximo intervalo
    float duty = 0.0f;
    if (g_mode == MODE_PROFILE) {
        const double t = (double)k * TS_US * 1e-6;
        double acc = 0;
        bool done = true;
        for (size_t i = 0; i < N_STEPS; i++) {
            acc += PROFILE[i].dur_s;
            if (t < acc) {
                duty = fminf(MAX_DUTY_PROFILE, fmaxf(-MAX_DUTY_PROFILE, PROFILE[i].duty_pct));
                done = false;
                break;
            }
        }
        if (done) { stop_run("#END"); return; }
    } else {   // MODE_MANUAL o MODE_STREAM
        const uint32_t lim = (g_mode == MODE_STREAM) ? WATCHDOG_MS : MANUAL_TIMEOUT_MS;
        if (millis() - g_last_cmd_ms > lim) { stop_run("#TIMEOUT"); return; }
        float target = g_manual_duty;
        if (g_mode == MODE_STREAM) target = fminf(STREAM_MAX_DUTY, fmaxf(0.0f, target));
        // Rampa: el duty aplicado se acerca al pedido a lo sumo RAMP_PCT_PER_S
        const float maxstep = RAMP_PCT_PER_S * (float)TS_US * 1e-6f;
        g_duty_cur += fminf(maxstep, fmaxf(-maxstep, target - g_duty_cur));
        duty = g_duty_cur;
    }

    // 4) Aplicar el duty inmediatamente (inicio del intervalo)
    motor_set(duty);

    // 5) Guardar el PWM realmente aplicado para reportarlo en la siguiente fila.
    // No se realiza espera ni medicion analogica de tension.
    g_prev_duty = duty;
}

// ---------------------------------------------------------------------
//  Comandos por serial
// ---------------------------------------------------------------------
static void exec_cmd(const char* c) {
    switch (c[0]) {
        case 'G':
            if (g_mode == MODE_IDLE) start_run(MODE_PROFILE); else Serial.println("#BUSY");
            break;
        case 'S':
            if (g_mode == MODE_IDLE) { g_manual_duty = 0.0f; start_run(MODE_STREAM); }
            else Serial.println("#BUSY");
            break;
        case 'X':
            stop_run("#STOP");
            break;
        case 'D': {
            if (g_mode == MODE_PROFILE) { Serial.println("#BUSY"); break; }
            g_manual_duty = fminf(MAX_DUTY_MANUAL,
                          fmaxf(-MAX_DUTY_MANUAL, (float)atof(c + 1)));
            g_last_cmd_ms = millis();
            if (g_mode == MODE_IDLE) start_run(MODE_MANUAL);
            break;
        }
        case 'I':
            print_info();
            break;
        default:
            Serial.println("#ERR,comando desconocido");
    }
}

static void handle_serial() {
    static char cmd[32];
    static uint8_t n = 0;
    while (Serial.available()) {
        const char ch = (char)Serial.read();
        if (ch == '\n' || ch == '\r') {
            if (n) { cmd[n] = 0; exec_cmd(cmd); n = 0; }
        } else if (n < sizeof(cmd) - 1) {
            cmd[n++] = ch;
        }
    }
}

// ---------------------------------------------------------------------
//  Arduino
// ---------------------------------------------------------------------
void setup() {
    Serial.begin(SERIAL_BAUD);

    pwm_init();
    motor_set(0);                     // PWM desactivado al arrancar
    encoder_init();

    g_task = xTaskGetCurrentTaskHandle();
    esp_timer_create_args_t args = {};
    args.callback = &tick_cb;
    args.name = "ts_timer";
    esp_timer_create(&args, &g_timer);

    delay(100);
    Serial.println("#READY");
    print_info();
}

void loop() {
    handle_serial();
    if (g_mode == MODE_IDLE) {
        delay(2);
        return;
    }
    const uint32_t n = ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(2));
    if (n > 0) {
        if (n > 1) g_missed += n - 1;     // ciclos que no alcanzamos a procesar
        do_tick();
    }
}
